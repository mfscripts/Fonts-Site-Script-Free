sunwalk fontworks

unzip to any folder, copy or send to c:\windows\fonts....

enjoy!


this font is freeware, but donations would certainly be
accepted.  if you'd prefer not to donate to me, help out
someone else in need...

comments to:

Andy Krahling
andy@sunwalk.com
http://www.sunwalk.com
sunwalk fontworks, manchester, nh

custom fonts available, contact me!