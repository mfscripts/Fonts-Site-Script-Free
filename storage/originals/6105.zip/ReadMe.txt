THE TEMPHIS RUNES - FREEWARE SAMPLER
TrueType Fonts and eToys for Gamers
Cumberland Games & Diversions
http://www.cumberlandgames.com

Thanks for trying out the Temphis Runes! This archive should contain three things:

* This ReadMe.TXT file (if this is missing, you're very strange)
* The Temphis Sampler TrueType font. Install this like any other font (see the Help feature in your operating system if you haven't installed a font before, or email me at sjohn@io.com for help)
* The Temphis Sampler PDF file. You'll need Version 4 or higher of the (freeware) Acrobat Reader from Adobe. If you don't have it yet (it's a great program) you can snag it from www.adobe.com

The font contains glyphs from all EIGHT quality fonts included in the full version. The PDF contains three pages from the seven-page "Rune Guide" eBooklet, and one of the three pages of Rune Cards. Print, read, and see if you like it! If you like it enough to buy a set, just visit us again at www.cumberlandgames.com - Either way, enjoy!

This archive may be freely distributed, provided all three
files inside it remain intact and unaltered. The materials included in this set are for private, non-commercial use only. The Temphis Runes are Copyright �2001 by S. John Ross. References to events, place-names and characters from Uresia: Grave of Heaven are trademarks of Guardians of Order, and are used with permission. Elements original to the Temphis Runes are the sole property of Cumberland Games & Diversions. You can visit Guardians of Order at http://www.guardiansorder.on.ca/