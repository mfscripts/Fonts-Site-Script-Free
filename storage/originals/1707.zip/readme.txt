fuelfontstypefoundry Shareware Fonts Readme!

COPYRIGHT NOTICES
all fonts � 1996-1998 claes k�llarsson /
fuelfontstypefoundry. all rights reserved.
these fonts are 10$ SHAREWARE fonts.
NOT FREEWARE!

PERSONAL USE
these fonts are SHAREWARE, that means you can use them
for free for 30 days and after that I hope that you are
kind enough to pay the 10 us$ shareware fee if you want
to use this font more. it's not a must to pay shareware
fees, most people don't pay but if you want to support
my work then it'd be very nice if you paid the fee.

COMMERCIAL USE
if you plan on using one of my shareware fonts in a
commercial project then it's not enough with just 10
us$, the price for using one of my shareware fonts in
a commercial project is 100 us$. Contact me at my email
address (grizzly@fucker.com) if you want to use on of
my shareware fonts in a commercial project!

(commercial project = advertisements, cd-booklets,
corporate websites, movie posters, etc)

if you like my shareware fonts, please send 10 us$
(or the 100 us$ commercial fee), and please send
ONLY CASH (10 dollar bill), it's much easier for
me to exchange, the bank won't accept foreign checks
anymore, well they do but they charge more than 10
dollars so I won't get anything for the check..
send the money here:
 claes k�llarsson
 skimmelv. 7
 85752 sundsvall
 sweden

REDISTRIBUTING FUELFONTS
if you want to re-distribute my fonts on your website I
have three rules i'd like you to follow:

1. always include the text-files (like this one).

2. link to my site so the people who download my fonts
   know where they can get more of my fonts and such.

3. never re-distribute all fuelfonts, only my site can
   give away all the fonts in the fuelfonts collection,
   just give away 5-6 fonts on your site and let people
   visit my site if they want more.

and please if you can, send me an email and tell me that
you are giving away my fonts! It would be much appreciated.
my email address is grizzly@fucker.com...

hope you'll enjoy my fonts,
			     claes

urls:
 http://www.fuelfonts.com
 http://www.chank.com/fuelfonts

email:
 grizzly@fucker.com

copyright � 1998 claes k�llarsson / fuelfontstypefoundry.
all rights reserved.