"No.Refunds" is a [totally free] font !!!

Use it as many times and as long as you wish.

I took this font from some old ticket from a San Francisco bay 
boat-tour. I had to add some letters though. I hope you like it.

If you are interested in more fonts then send me an e-mail at: 
nonsuch@cuci.nl or for fastest reply at: hannmueller@metronet.de
I do web-site designs, poster designs, t-shirt designs, and a lot more,
too.

"No.Refunds" is copyright Christoph Mueller 1997. This font may not
be sold or/and altered without my written permission.
This font may be redistributed freely as long as this file is included.
Please let me know if you want to redistribute this font at your site.
