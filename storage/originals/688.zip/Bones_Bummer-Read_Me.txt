Merci d'avoir t�l�charg� Bones Bummer!
Cette fonte est un Abreuvware, vous pouvez l'utiliser gratuitement � but personnel et si vous �tes gentils vous pouvez m'envoyer une bi�re locale  ! (n'h�sitez pas � m'envoyer vos boulots faits avec ma police, �a m'interesse !).  Cette fonte est fortement inspir�e de la pochette du vynil de Bones Brigade appel� Endless Bummer, dessin�e par Sam V.
Merci de toujours laisser ce fichier Read_Me avec la police.
Si vous voulez vous en servir � des fins commerciales, merci de me contacter par mail � daaams@laposte.net !

daaams@laposte.net  |  http://www.daaams.fr.st

--------------------------------------------------------------------------------------------------------------------------------------------------

Hi, thanx for downloading Bones Bummer!
This font is a Drinkware, you can use it for free for your personnal use only, and if you're nice you can send me a bottle of local beer (and don't hesitate to send me samples of your work, made with this font). It's strongly inspired from Bones Brigade's Endless Bummer artwork, done by Sam V.
Always keep this Read_me file with the font.
If you want to use it for commercial purpose, please drop me a line at daaams@laposte.net !

daaams@laposte.net  |  http://www.daaams.fr.st