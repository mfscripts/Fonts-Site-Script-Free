DS Down Cyr (Ghostmeat - old)
----------------------------------------------
D-Studio (Moscow) & Ray Larabie.(USA)
(c)1997-98, All rights reserved.
Freeware version.

* * * * * * * * * * * * * * * * * * * * * * * *

Feel free to share this font with others,
but please include this documentation.

Thanks,

Nikolay and Ray


* * * * * * * * * * * * * * * * * * * * * * * *

D-Studio (Moscow)
http://wt.aha.ru/d-studio/
webart@tomcat.ru
Dubina Nikolay

* * * * * * * * * * * * * * * * * * * * * * * *

Ray Larabie.(USA)
http://www.goldenapplecomics.com/larabiefonts/
Ray