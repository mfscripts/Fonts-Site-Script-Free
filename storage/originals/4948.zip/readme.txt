Skeldale House Treasures
Shareware dingbats (fonts) end users license agreement

You are "NOT" permitted to distribute this dingbat (font) for
others to use, with out written "Permission" and as long as this document is included along with the dingbat and not modified in any way, authorship is credited and add a link back to Skeldale House Treasures.
http://www.mcn.net/~skeldale


Do not include this dingbat (font) in any other collections
<i.e. cd-roms or other collections on the internet for download> without written consent from Skeldale House Treasures.  This dingbat (font) is not to be resold or remarketed.  This dingbat can be used for any purposes once Shareware Fee is paid. 

Share Ware fee is $1.00 US funds.
Payable to
Robyn Phillips
215 Cooper Drive
Cascade, Montana. USA
59421-8406

Thanks and Have Fun and Enjoy!!!!

Copyright 1998, Skeldale House Treasures, All Rights Reserved

http://www.mcn.net/~skeldale
skeldale@mcn.net