Yet another Kiwi Media font!

Galaxia!

3 weights - Planetary, Nebulous and SIngularity.  I attempted to achieve a sort of 
techno-ish retro-futurist look with this one.   Has a full character set.

Pitiful shareware fee:
		If you can find it in the depths of your soul and/or your pocketbook,
		I'd appreciate $10 for this family of fonts.  However, if you can't swing that
		(if you're a student or somesuch) just send me email and I'll waive the fee.  If you
		do intend to use this work in a piece for profit, I heartily suggest paying 
		the shareware fee, since that's just good business.
		
For more information, please contact wonko@itis.com or http://www.itis.com/kiwi/

Thanks.

-Eric
