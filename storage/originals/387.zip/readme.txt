All Kung-Fu Fonts are copyright Mike Lecky (mike@superfunk.com)
Redistribute freely.
Visit www.superfunk.com for more free fonts.