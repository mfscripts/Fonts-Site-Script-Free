(  _) /  \( \( )(_  _)(  \/  )(  _)/ __) (  )    / _)/  \(  \/  )
 ) _)( () ))  (   )(   )    (  ) _)\__ \ /__\  _( (_( () ))    ( 
(_)   \__/(_)\_) (__) (_/\/\_)(___)(___/(_)(_)(_)\__)\__/(_/\/\_)

Font Name - Ferro Rosso v1.0 (Freeware)
*******************************************************
Designer: Michael Hagemann www.fontmesa.com

Available for PC Truetype
Uppercase & Lowercase: Yes
International Characters: No, but will be available in future commercial release.
Euro symbol: Yes
Kerning: Yes


Ferro Rosso is a font based on the Famous logo from Ferrari Automobili
Italiano automobile manufacturer.

About using a famous font.

The fonts at FontMesa that are patterned after famous company logos although 
very accurate in detail have not been approved as official art work by the companies
which logos they've been designed after. They were created for entertainment purposes
and if you plan on using the famous logos from these fonts for any legitimate
or commercial purpose then it is recommended that you contact those companies
and request guideline information for use or display of their logo and or information
on licensing the use of their logo, usage of any other combination of letters
is free from any trademark infringement.

Most companies will allow the use of their logo for non commercial use such as
a Coca Cola can collector web site that displays a personal collection of Coke cans
or an individual displaying Miller Lite on their pickup truck because they love the
product but some companies are very strict when it comes to using their logo
for any purpose and it's always best to check with them before using their logo.



