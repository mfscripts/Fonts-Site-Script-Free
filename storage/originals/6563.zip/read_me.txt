DS Podd Cyr (CaptainPodd - old)
----------------------------------------------
D-Studio (Moscow) & Uddi Uddi.(USA)
(c)1997-98, All rights reserved.
Freeware version.

* * * * * * * * * * * * * * * * * * * * * * * *

Feel free to share this font with others,
but please include this documentation.

Thanks,

Nikolay and Uddi


* * * * * * * * * * * * * * * * * * * * * * * *

D-Studio (Moscow)
http://wt.aha.ru/d-studio/
webart@tomcat.ru
Dubina Nikolay

* * * * * * * * * * * * * * * * * * * * * * * *

Uddi Uddi.(USA)
http://www.netspace.net.au/~joison/uddi/fonts/fonts.htm
uddiuddi@earthling.net
Uddi Uddi