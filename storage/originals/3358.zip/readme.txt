	This font was made by:

	    dave kellam
	<kellam@recorder.ca>
	  icq: 3777073

	  Original design by:

          brian stuparyk
	<trollusk@fuse.net>
	  icq: 17322295

   If you want to distribute this, mail me.
   I'll probably let you.  Just don't put
   it up on a site and say it's yours
   and tell people to pay you.  If you
   want to use this for commercial stuff
   give me some money!


	�1998 SpaceMonkey Fonts
     http://cc.recorder.ca/~monkey/