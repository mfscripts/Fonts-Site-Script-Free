
This font, "Newfie," is a handwriting typeface inspired by the
handwriting of a genuine Newfoundlander - a particularly cute and
funny example of the species, my lovely wife Sandra! It contains
nearly all the characters visible on an ordinary American keyboard.

This font is copyright 2000 by S. John and Sandra Ross. It is
freeware; no license is required to use it. All I ask is that if
you put it to any interesting use, you let me know so I can feel
all warm and fuzzy. You can download the natural companion to
Newfie, a font called Lunatic (based on my own handwriting) at
the Cumberland Fontworks. Give us a visit!

NEWFIE.TTF Version 1.0 - Initial Release
A Product of Cumberland Games & Diversions(TM)
sjohn@io.com
www.cumberlandgames.com