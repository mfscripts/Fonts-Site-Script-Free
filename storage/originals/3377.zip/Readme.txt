Nu World Fonts, version 1.2 (May 12, 1997)

Free Fonts!
Okay, here's what I'm trying to do: remember eWorld, Apple Computers online
service? Well, I've been trying to recreate the look of eWorld on the internet
for about a year now. So far, I've been able to do some fancy tables to simulate
the main navigation elements in eWorld.

But something was missing. One of the really great things about eWorld was the
fonts that they used to display headings and descriptions. A variant of Helvetica
Condensed was used for headings and 9pt Epsy Sans was used for the descriptions
underneath. I've tried in the past to simulate that by using bold for the
headings, but now with the introduction of the <FONT FACE> tag, I can now really
do an accurate representation of eWorld looked like.

The only problem is that not everyone has these fonts, so I have created two new
fonts, designed for use on-screen and on your printer and am giving them away.
The are: Nu World and Nu World Tight.

The original eWorld fonts were simply bitmaps, and were not meant to be printed
out. My fonts are TrueType and can be printed without "the staircase effect." You
can download them from the link below. Let me know what you think of them and
drop me a note if you want to create an "eWorld-esque" site of your own. I have
some templates and icons that you can use. Also, please feel free to e-mail me
any screen shots you have laying around from eWorld.  My e-mail address is
<wamozart@teleport.com>

    _/     _/      _/_/_/_/  Marty Pfeiffer, a.k.a Scooter Boy
   _/_/  _/_/     _/    _/  Font Designer
  _/ _/ _/ _/    _/_/_/_/ 
 _/  _/_/  _/   _/        See brand, spankin' new typefaces and music at:
_/   _/    _/  _/       <http://www.teleport.com/~wamozart/>
