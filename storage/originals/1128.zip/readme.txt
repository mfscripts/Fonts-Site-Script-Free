Pharmacy computer font �2000 Harold Lohner

FREEWARE-Distribute freely.

Based on the lettering of the sign of a local pharmacy.

HLohner@aol.com
http://members.aol.com/fontner

