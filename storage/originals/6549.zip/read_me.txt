DS Army Cyr (BraesideLumberboy - old)
----------------------------------------------
D-Studio (Moscow, Russia) & Ray Larabie.(Ontario, CANADA)
(c)1997-98, All rights reserved.
Freeware version.

* * * * * * * * * * * * * * * * * * * * * * * *

Feel free to share this font with others,
but please include this documentation.

Thanks,

Nikolay and Ray


* * * * * * * * * * * * * * * * * * * * * * * *

D-Studio (Moscow)
http://www.wt.aha.ru/d-studio/
webart@tomcat.ru
Dubina Nikolay

* * * * * * * * * * * * * * * * * * * * * * * *

Ray Larabie.(CANADA)
www.delirium.com/larabiefonts
www.swankarmy.net/larabiefonts
www.goldenapplecomics.com/larabiefonts

rlarabie@swankarmy.net
rlarabie@hotmail.com