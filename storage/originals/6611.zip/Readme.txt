******* JOKE REGULAR ************************
******************************************************
Copyright (c) Denis A Serikov. 25.12.2001.
Freeware version.

************************************************************
** TYPE: True Type/ Type 1 Font ********************

** Dos Name: JOKE____ (ttf) JK______ (type1) **

** KERNING: 1628 Pairs ******************************
************************************************************

************* The KIT ************************************

True Type Font.         70kb
Type1 Font.             35kb
Readme File.  (txt).   859bt
Fontface File (pdf).    33kb

*************************************************************

 Denis A Serikov. All rights Reserved! 2002.
 E - Mail: denis_box@mtu-net.ru.
**********************************************

P.S. *** Thank you! *** 