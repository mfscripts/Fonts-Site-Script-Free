Old Typewriter 

This font is Shareware, which means if you send $15 tome, you may 
use it.  Info on registering this font is on the bottom.
 
This font is baised on the typewritter my father still uses to type 
letters on.  It's a huge HEAVY black monster that doesn't even have 
the number 1 because they figure you can just use
an l.

I though it had an interesting style, so I had my dad type in every 
character and worked off of that.  Some of the characters in the font 
are characters that weren't on the keyboard, so I just made them
up.  The characters I created are:  !  1  =  +  ~  \  �  �  �  �
The rest of the characters were on the typewritter.

I have 3 versions of this font:
     Messy.  This version is the most complex.  Low memory apps 
*may* have trouble with it.  It probally won't look much different 
than Simplified unless it's printed at 24pt or larger text.  Especially if 
your final out put is screen resolution you probally don't need to use 
this version often
     Simplified.  This is just a scaled down version of Messy.  It is 
quicker and looks fine
for anything on screen, or small printouts.  It is also useful if you 
want your final output to look "cleaner" around the edges, and have 
less gaps in the letters
     Skimpy.  This works well when interdispersed with the others, or 
when it's supposed to look like the ribbon is almost out on the 
typewriter.  I personally think this version is the most fun, although 
it's not as legable as the others.


Also take a look at my other fonts:  Loony and Scratchy Mess!
_____________________________________________________________
____
For Great Shockwave Games check out:    http://GravitySwitch.com/
_____________________________________________________________
____

INSTALLING OLD TYPEWRITER
Mac system 7.1 and higher
Drop the true type font into your system folder

Mac Older systems
You must use Font/DA Mover from Apple computer to install the 
bitmap font's into your system.

Windows machines
Just drop the font in the fonts folder. 

Unix machines
If you use unix I hope you can hack something together.



Legal crap:
�1996 Jason Mark all rights reserved.  No warrantees are implied, 
and this font may not be suitable for your purposes.
You may use this font for up to one month for free, after that time 
you must register it as discribed below.  
Any Non-profit organization may use this font for free.
It may be distributed free as long as this notice is included with the 
font file.
This font may not be sold or altered without my written permission.   
Fees may be charged in association with this font, however, such as 
by users' groups for duplicating fees, commercial services for 
downloading time, etc.
I interpret the sale of Loony on commercially prepared �public 
domain disks� as a sale of this font against my expressed 
instructions. 
If you wish to distribute this font please contact me (contact info 
below).

To register send at least $15 to:

Jason Mark  
116 Chestnut St
Branford, CT 06405

Also please include your name and where you obtained this font.

for more info contact me at: jmark@cs.umass.edu   
http://rastelli.cs.umass.edu/~ckc/alab/people/jason/


for the ultimate WWW site for font's check out Norman Walsh's 
amazing site:
http://jasper.ora.com/comp.fonts/Internet-Font-Archive/ifa3.htm
