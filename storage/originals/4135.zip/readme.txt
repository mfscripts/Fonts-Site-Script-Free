Captain Howdy computer font �2000 Harold Lohner

FREEWARE-Distribute freely.

Based on the lettering on a classic Ouija� board.

HLohner@aol.com
http://members.aol.com/fontner