==================================
Unreal Tournament Font Version 1.0
   by Rah'Dick - rahdick@gmx.de
==================================

[German]

Jawoll, ich habe eine komplette TTF-Schriftart gemacht, die im Stil der Buchstaben des UT-Titelbildschirms gehalten sind.

Im Moment gibt es noch Probleme, was Nicht-Deutsche Betriebssysteme betrifft (z.B. Ungarisches Windows), aber das l�sst sich auch noch beheben... In einer zuk�nftigen Version.

__________________________________

[English]

Yes, I made a complete TTF-Font in the style of the characters on the UT title screen.

At the moment, there are still some problems with operating systems with a different language than German (e.g. Hungarian Windows), but they will be compensated in later versions, I guess.
__________________________________

Rah'Dick
rahdick@gmx.de
ICQ: 68430821
