------------------------------------------------------------------
OUTER LIMITS v1.0, created by ShyWedge, 1999.
------------------------------------------------------------------

The following TrueType fonts are included:

 - Outer Limits
 - Outer Limits, Italic
 - Outer Limits Extended
 - Outer Limits Extended, Italic
 - Outer Limits Solid
 - Outer Limits Solid, Italic
 - Outer Limits Solid Extended
 - Outer Limits Solid Extended, Italic

v1.0 FEATURES
------------------------------------------------------------------

 - Lowercase and uppercase letters, and numbers (punctuation not
   included in this version).
 - Proper spacing and kerning.


This font package is Freeware.  If you wish to distribute it,
please include all of the above fonts along with this document
and send me an e-mail to let me know which font you have so I can
inform you of the latest updates.

Thank you for downloading this font package and enjoy!

ShyFonts by ShyWedge, 1999.
------------------------------------------------------------------
Web Site:  http://welcome.to/ShyFonts
E-mail:    ShyWedge@yahoo.com