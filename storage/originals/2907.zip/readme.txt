TrueTypeFont: Fruitopia
Dennis Ludlow 2001 all rights reserved
Sharkshock Productions
maddhatter_dl@yahoo.com

Hi there font fans. Just another fruity font to quench your thirst. Feel free to re-distribute for
non-commercial use. If you like this font or another that i've made, email me and please let me
know! Flattery will get you everywhere. Take care everyone.
check out my graphic archive at www.sharkshock.uni.cc
                                  "because boring design SUCKS!"