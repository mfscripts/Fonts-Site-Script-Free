*------------------------------------------------------*
                   T H E  E N D .
*------------------------------------------------------*

 This is the end, my only friend - the end..
 It took a while to make this font, I should take
 money for it but I dont! Its free.
 I made it for all you Sociopaths out there.
 You remind me of the bitter end.
 WRITE ME A LETTER AND SAY IF THE FONT IS OK, AND SAY
 THANKS. REMEMBER THIS IS NOT FREEWARE, ITS LETTERWARE
 
 Donate your salary to me -> contact: fonts@mrfisk.com

*------------------------------------------------------*


 |-------------------*  Frequently Asked Questions : *----------------|
   
   � Can I use the fonts for commercial things, such as things I might
     get money for? Can I buy the font/fonts?

   � No!! If you want to do that you'll have to contact me first and
     get my permission. And we must set a deal, how much money I can
     earn from it. You can buy the font, it will cost between $10 - 
     $20 then you'll have the full rights to it.

 |--------------------------------------------------------------------|

   � Can I use the fonts on my webpage?

   � Yes, if it's a free webpage. If you aint making any money thru
     it, that means if you make a clickthru banner etc, with my font
     on it, you are making money thru my font. It have to free all 
     over or else it's not allowed.

 |--------------------------------------------------------------------|

   � Can I put up the font-file/files for download on my page?

   � Yes you can. But you'll have to leave the file as it is, ex
     if the fontfile name is something2000mg.zip you'll have to 
     leave it that way. And it MUST include all original files such
     as the .ttf file and the readme.txt file + other. You cant
     change anything inside them, or else its not allowed. And you
     have to write a link next to the file where you downloaded it,
     that it is taken from MR.FISK FONTS - http://fonts.mrfisk.com

 |--------------------------------------------------------------------|

   � Can I include the fontfiles on a cd-rom wich I am going to sell?

   � No!! You'll have to contact me first and get my permission. Its 
     the same laws as question nr 1 in this faq.

 |--------------------------------------------------------------------|

   � So you dont want anything for the fonts I download?

   � Yes I do. When you have installed the font/fonts you'll have to
     write me a proper Thank You mail, because this is not freeware
     its Letterware. Or you can write something nice in my guestbook.

 |--------------------------------------------------------------------|

   � Any other questions regarding what fontrules are on and off,
     write to: fonts@mrfisk.com

 |--------------------------------------------------------------------| 

*------------------------------------------------------*

 Have a nice day. / MR.FISK - 01:41 2000-11-06 - Sweden

*------------------------------------------------------*
 
 Say at least THANKS, 
 write to; the.end@mrfisk.com

*------------------------------------------------------*

 Hail Satan!      

                    OOOO
                    OOOO
                    OOOO
                    OOOO
                    OOOO
                    OOOO
                    OOOO
             OOOOOOOOOOOOOOOOOO
             OOOOOOOOOOOOOOOOOO
                    OOOO
                    OOOO
                    OOOO                   He he he...