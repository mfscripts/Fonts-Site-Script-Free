
<snip>

Hi!  Here are some of my fonts that are freely available for distribution.  I
hope you and everyone who visits your site enjoys them.  The only thing that I
ask is that credit is given to show I am the creator.   Thanks for your time
and enjoy these fonts!!!

Kid Chaos!

ChaosFonts - a proud member of the Fontface Guild.

</snip>