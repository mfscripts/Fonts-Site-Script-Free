blob.ttf

unip to any folder, copy or send to c:\windows\fonts....

enjoy!

comments to:

Andy Krahling
matsuan@aol.com
sunwalk fontworks, manchester, nh

custom fonts available, contact me!