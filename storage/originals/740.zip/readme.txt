This font is copyright Amy VanTorre 2005. It's free for use, as long as you don't claim it as your own.

The fonts were created with Corel Painter Nine.

Enjoy.