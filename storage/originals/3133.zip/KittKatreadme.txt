TrueTypeFont: KittKat
Dennis Ludlow Productions 2000 all rights reserved
Sharkshock Productions

Hey there font collectors. Im happy to bring out this long awaited (and much debated) candy
font. In high school, i ate more KK bars than pizza and cheesburgers combined. My blood type 
was chocolate. Once, i washed a pair of jeans with them in one pocket, and a $5 bill in the other.
I was more upset about the chocolate. Yes im a chocolate freak. If you like this font, mail me
some.............or...dont.
check out my graphic archive at www.sharkshock.uni.cc
                                  "because boring design SUCKS!"