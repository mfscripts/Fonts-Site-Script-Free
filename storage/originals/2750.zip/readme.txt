TrueTypeFont: Dark Crystal (Outline)
Dennis Ludlow 2001 all rights reserved
Sharkshock Productions
maddhatter_dl@yahoo.com

Hey there everyone. A long time in the making, many years of renting, and 30 requests later,
you asked for a font that paid tribute to one of the most memorable Jim Henson movies
ever made; and now i proudly give you the Dark Crystal. A few things about this font here: 
First of all, it should NOT be used for data purposes because most almost all the symbols are
not present. Additionally, do not use this font in ALL CAPS because you're just asking for
trouble. You will find that if you hit the colon and semicolon, you can spell out the Dark Crystal
in two different weights. This has been my most difficult font so far and it's nearly 8:42 in the morning
(i starting working on this at 9pm) If you love the movie, and you like the font, please email
me simply let me know. Im a sucker for flattery :-) Take care everyone.
check out my graphic archive at www.sharkshock.uni.cc
                                  "because boring design SUCKS!"