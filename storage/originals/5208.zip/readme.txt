Thank you for choosing Vintage Type. We think you'll find our fonts useful and diverse and, hopefully, enjoyable to use.

Before installing and using your fonts, please be sure to read your End User License Agreement.

If you have trouble, please write to help@vintagetype.com. We'll work quickly to resolve your problem.

Please visit the Vintage Type web site for tips and general information.

Sincerely,
Mark Thomas & Susan Townsend
Vintage Type 

http://www.vintagetype.com/