This is a freeware font...have fun with it! 

Legal mumbo jumbo: 

This font was created by me, KatNMI@aol.com and is FREE to use for PERSONAL USE ONLY.  It may NOT be used for commercial purposes or sold in any way.  

My fonts MAY be placed on any website available for download, providing proper CREDIT is given<BR>
to me and this README.txt file is left in tact and attached.

I am not and can not be held resposible for any damages incurred to any computer after installing and/or using this font.

All fonts have been made with freeware/royalty free images.  If you made any of the images or know who did, write me and I'll remove it from my site immediately upon confirmation.  No need to get all IPPITY :)

If you use this font, send me the link!  I'd like to see what you did with it and add your URL to my page.

You can see all of my fonts at http://members.aol.com/katnmi/funfonts.htm

If you like this font, let me know!  Send your mail to katnmi@aol.com. 

Hugs

Kat