This font was created by Eduardo Recife.
Its a freeware typeface, so you can share it
with other people and use it for free. 

I used to belong to Atrophy Fonts which is gone.So now
Im running my on site "Misprinted Type".

These fonts are not supposed to look fancy and pretty
but for being alternative fonts for alternative designs.
So thats why most of my fonts looks dirty or misprinted.

This font is copyrighted by ME, so dont change the
font look or info and of course dont charge for it.

I would like to hear comments or suggestions about
my fonts, so please email me: recifed@terra.com.br
ICQ- 46873436

Visit Misprinted Type at: 
http://misprintedtype.cjb.net    or
http://planeta.terra.com.br/arte/type/

If youre having downloading problems get my fonts straight at:
http://moorstation.org/typoasis/designers/recife/eduardo01.html

Enjoy!
Recife
