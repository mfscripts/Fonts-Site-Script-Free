WOLVES AND RAVENS
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

This is a simple fantasy font based on a player handout I created
for a fantasy campaign in my teenage years. There was a cryptic
message - "Wolves and Ravens Devour the Unwary" - carved into the
side of a wooden footbridge, as an omen of things to come. The
handwriting was meant to represent a quasi-runic style of Roman
letters, of the sort that might be crudely carved with a dagger
into the soft wood of the bridge rail.

This font expands those characters into a full alphabet of 26
letters, plus 0-9 and a squarish "bullet" that serves as a 
generic sort of punctuation mark. These are the only characters
in the font.

This font is copyright 2000,2002 by S. John Ross. "Wolves and Ravens" and "Cumberland Games & Diversions" are trademarks of S. John Ross. This font is freeware for personal, non-commercial use of any kind (including website decoration and so on). Contact me at sjohn@io.com if you're interested in a commercial license; rates will depend on the details.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 3.0