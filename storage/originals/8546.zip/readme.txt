Hey. Thanks for taking my font. Hope you enjoy.
This font is free. You may use it for any publications without contacting me. 
But if you are to put it on a CD or other software package for sale, e-mail me at swat_kat@hotmail.com.
We can then work out an agreement for the distribution of it. You may not sell this font
on any web page or change it around to claim you made it. You can put it on any freeware font
site for redistribution as long as you keep all the files in the .zip together.

Chaotic Circuit is copyright (c) 1998 Swat Kat.
e-mail:swat_kat@hotmail.com
web page: http://bionictype.cjb.net