Inspired by the sixties Batman series and some old comics, this dingbat is perfect for comic book enthusiasts. This font is the one of the first (if not the first) three-way collaborations in font history .. that we know of. Dan from Iconian Fonts provided the text font [Comic Book Commando], helped me think of the words to put in the bubbles, cleaned up the font, and added the uppercase set. Brian from Astigmatic One Eye providing the buttons via his font ButtonButton AOE, added a few characters, and also cleaned up to produce the the final version of the font. I, Jev, [YeahBuddy!] thought of the concept and put all the elements together and fonted the original first version. The three of us did some work to finish it off, and.. ta da!

This font is freeware. You may use it freely (hence the "free" in "freeware") for non-commercial purposes. 

YeahBuddy Fonts -
http://www.typesource.com/Presents/YeahBuddy/

Iconian Fonts -
http://iconian.shyfonts.com

Astigmatic One Eye - 
http://www.astigmatic.com