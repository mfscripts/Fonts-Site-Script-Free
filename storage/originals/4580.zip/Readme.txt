13th Degree Font Foundry
All Files included are Copyright 1999 Zane Townsend.

Web Site:  http://members.xoom.com/13th_degree/
Email:    ztownsend@hotmail.com
______________________________________________________________________________

Revision notes:  None, 1st release.

Special character notes:  To add more orbits around your capital letters use the open bracket, close bracket and backslash keys before the letter. Example keystrokes [\M will give you 3 orbits around M. There is a known spacing issue with orbits around lower case letters that I hope to fix by the next release. 

Other Notes: I made this font for my girlfriend Lisa, she studies Japanese language so I titled it with the Japanese pronunciation, Misa or Risa are both acceptable but I went with Misa because that's the way Lisa was pronounced in my favorite Japanese show
Macross.

______________________________________________________________________________

This font package is Shareware. If you wish to distribute it,
please include all of files that came with along with this document
(consisting of; license.txt, license.htm, Readme.txt, file_id.diz, 13th_degree.url, and all other files included with the original.)  


If you would like to be added to my mailing list, please send me an email
with "Update" as the subject.
