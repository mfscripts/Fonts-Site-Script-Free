This font is called Arctic.  I made it on October 30th and 31st, 2000.  

The font is a study in arcs.  I drew the characters in Illustrator using circle segments and lines and saved them as bitmaps.  Then I pulled the bitmaps into the trial version of Font Creator Program to map the characters to the appropriate keys. This font contains the 26 basic letters of the alphabet in upper- and lower-case letters.  It also includes some common diacritics, including "e" and "a" with accute and grave accents and a circumflex "i" and an "i" with an umlaut over it.  I also created the numbers and all the basic punctuation marks and mathematical symbols.

Use this font to your heart's content.  If you do, and if you like it, maybe drop me an email at houstond@esper.com just to give me a little thrill.  

Daryl L. Houston
http://www.ibiblio.org/poetry99/dlh