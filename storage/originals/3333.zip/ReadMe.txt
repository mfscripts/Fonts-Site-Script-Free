NAMELESS HARBOR
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

Nameless Harbor (named for a creepy city in the creepy Pok�thulhu Adventure Game, by creepy game designer Me) is a kind of "traditional Halloween font," if there is such a thing. It's more angular than drippy, though - I went for the occasional twisty-pointy bit. It's a batwinged sort of font. Good for creating player handouts for a "Scooby-Doo" style RISUS (The Anything RPG!) Campaign ...

Nameless Harbor is a full keyboard small-caps set, plus two foreign glyphs (fans of Pok�thulhu can probably guess which). The original master was hand-doodled at the Ruta Maya coffeehouse here in Austin, Texas, while giving my mind a break from game stats.

This font is copyright 2001 by S. John Ross. "Nameless Harbor," "Risus: The Anything RPG" and "Cumberland Games & Diversions" are trademarks of S. John Ross. "The Pok�thulhu Adventure Game" is a trademark of Phil Reed and Russel Godwin. This font is freeware for personal, non-commercial use of any kind (including website decoration and so on). Contact me at sjohn@io.com if you're interested in a commercial license; rates will depend on the details.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0

