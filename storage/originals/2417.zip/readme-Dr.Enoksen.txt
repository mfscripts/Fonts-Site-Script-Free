    _  _ ____ _    _    ____    ___ _  _ ____ ____ ____
    |__| |___ |    |    |  |     |  |__| |___ |__/ |___
    |  | |___ |___ |___ |__|     |  |  | |___ |  \ |___


----------------------------------------------------------------


the Dr.Enoksen font has arrived. Its free like the others.
Have fun and dont forget the condoms.


----------------------------------------------------------------

MR.FISK Official Font-Hole   : http://www.fiskish.net/fonts.shtml
MR.FISK Unofficial Font-Hole : http://hem2.passagen.se/akkustic/

-----------------------------------------------------------------

Write when u have installed it on yer computor..
fuck-the-world@mail.ru

Takecare/ : / Mr.Fisk (25/4-99)