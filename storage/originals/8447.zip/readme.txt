[freeware]


�TarmSaft
email: Ola Bj�rling <ola@techno.org>


http://home4.swipnet.se/~w-46346/

Anyone from Sweden (we try to be as Swedish as possible) is
welcome to submit a font to TarmSaft.
