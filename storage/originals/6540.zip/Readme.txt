******* Destiny Light ******************************
****************************************************
Copyright (c) Denis A Serikov. 2001.
Full version.

****************************************************
** TYPE: True Type/ Type 1 Font ****************

** Dos Name: DESLIGHT (ttf) DESL____ (type1) 

** KERNING: 952 PAIRS ************************
****************************************************

************* The KIT *****************************

True Type Font.        132kb
Type1 Font.                80kb
Readme File.  (txt).       1kb
Fontface File (pdf).      53kb

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Feel free to share this font with others,
but please include this documentation.

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

 Denis A Serikov. All rights Reserved! 2001.
 E - Mail: denis_box@mtu-net.ru.
**********************************************

P.S. *** Thank you! *** 