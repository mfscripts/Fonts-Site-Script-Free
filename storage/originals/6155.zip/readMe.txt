futurexBob truetypefont


By downloading this font you agree to the following terms
of use:

 - This font is freeware.

 - This font may be distributed ONLY via the Internet for
   FREE. Under NO circumstances may this font be sold for
   a profit nor be included as part of another product or CD-ROM
   compilation. If you wish to include this font for FREE
   distribution on your website, please  include all 
   documentation and graphics supplied with this font.

 - You may install and use this font on an unlimited
   amount of machines.

 - You may NOT rename, edit, or create any alternate variations of
   this font.

 - This font comes "as is" with NO warranty whatsoever.
   joeBob graff-X accepts NO responsibility for any damages or loss of
   any kind due to the use of this font. The use of this
   font is solely your responsibility -- you use this font
   at your own risk.

 - Enjoy the font!

If you have any question regarding this document or the usage of
this font, feel free to contact me at jeroen_bosch@yahoo.com.
Thank you for downloading this font and be creative!

------------------------------------------------------------------------
�2000 joeBob graff-X parts used from Futurex font