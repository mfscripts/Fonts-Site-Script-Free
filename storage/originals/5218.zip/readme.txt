All fonts is � 1997 of Claes K�llarsson.
All Rights Reserved.

All unautorized spreading or selling is strictly prohibited,
don't remix or remake these fonts without me knowing about it.
check out http://home1.swipnet.se/~w-14081/betatestfonts/ for
more fonts.
If you want to give these fonts away on your homepage,
please include this readme file and email me that you are
going to do it. I don't like finding out myself that someone
else is distributing my fonts without my knowledge.
Email me at: grizzly@royal.net

Enjoy!