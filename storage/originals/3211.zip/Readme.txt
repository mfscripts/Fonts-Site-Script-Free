"Last Ninja"  -  TrueType Font
 (c) 2000 by ck!  [Freaky Fonts]

The personal, non-commercial use of my font is free.
But Donations are accepted and highly appreciated!
The use of my fonts for commercial and profit purposes is prohibited,
unless a small donation is send to me.
Contact: ck@freakyfonts.de
These font files may not be modified or renamed.
This readme file must be included with each font, unchanged.
Redistribute? Sure, but send me an e-mail.

If you like the font, please e-mail: 
ck@freakyfonts.de

Visit .:Freaky Fonts:. for updates and new fonts (PC & MAC) :
http://come.to/freakyfonts
http://www.geocities.com/Area51/Shadowlands/7677/

Thanks to {ths} for the Mac conversion.
ths@higoto.de or visit: http://www.higoto.de/ths

Note:
The font includes some dingbats.
Visit the Last Ninja Archives @  http://www.lastninja.c64.org