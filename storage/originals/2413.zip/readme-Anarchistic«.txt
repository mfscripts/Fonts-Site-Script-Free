    _  _ ____ _    _    ____    ___ _  _ ____ ____ ____
    |__| |___ |    |    |  |     |  |__| |___ |__/ |___
    |  | |___ |___ |___ |__|     |  |  | |___ |  \ |___


This is the new font - Anarchistic�
I hope you like it.

***********************************************************************

Write me when you have put it into your computor:
fuck-the-world@mail.ru

***********************************************************************

The small Unofficial FontHole: http://hem2.passagen.se/akkustic/
The big Official FontHole:     http://www.fiskish.net/fonts.shtml

***********************************************************************

TakeCare/ : Mr.Fisk (23/4-99)