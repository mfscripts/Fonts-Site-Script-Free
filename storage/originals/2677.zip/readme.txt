Author:             Chris <n9603057@scholar.nepean.uws.edu.au>

The font is Mainly used as a heading since only capitals are available.
Called CapConstruct because of it's block quality.

11-10-97


