              

  ::   Maryellen TTF   ::


    Please keep this txt file with the font

    This original font was created by Ryan for you

    Please email him at ryn@goateestyle.com 

    This font is distributed by "Goatee Style"
    http://www.goateestyle.com

    Brought to you by the kids at "BrainStorm Designs"
    offering web design, graphics, art and more.
    http://www.brainstormdesigns.com

    You are free to use this font for any purpose 
    other than selling it.  Please let us know how 
    you used it.... thanks.

    Copyright 1999

    
