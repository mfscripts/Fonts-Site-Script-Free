Metro-DF computer font �2000 Harold Lohner

FREEWARE-Distribute freely.

Based on the official lettering of the Mexico City subway.

HLohner@aol.com
http://members.aol.com/fontner