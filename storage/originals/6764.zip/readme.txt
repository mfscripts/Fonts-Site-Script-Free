fONT MADE bY mE. iT's sUPPOSED tO bE a hANDWRITE mADE bY A cOMPUTER, cUTE iSN't iT?|
	      |
	      |
  	      |bROUGHT TO yA BY tERRANOVA