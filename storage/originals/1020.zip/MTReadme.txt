"Mom'sTypewriter" is a [totally free] font !!!

Use it as many times and as long as you wish.

There's really not a lot to tell about this font. I just typed the
whole alphabet on my mom's old typewriter, scaned it, and and made
the font.

If you are interested in more fonts then send me an e-mail at: 
nonsuch@cuci.nl
I do web-site designs, poster designs, t-shirt designs, and a lot more,
too.

Mom'sTypewriter is copyright Christoph Mueller 1997. This font may not
be sold or/and altered without my written permission.
This font may be redistributed freely as long as this file is included.