DECO FREEHAND
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

Deco Freehand is a "rapid-fire" font I created on February 19th and 20th of 2001, to settle my mind while working on a book for Guardians of Order (and letting my mind wander to my Fly From Evil project, which may incorporate this font in some way). I drew the sample at the Ruta Maya coffeehouse downtown (one of my favorite writing spots) in about 15 minutes. I created the font the next day in a process that took almost exactly an hour. The font is an all-caps poster font; only letters, numerals, exclamation mark and question mark are included.

This font is copyright 2001 by S. John Ross. "Deco Freehand" and "Cumberland Games & Diversions" are trademarks of S. John Ross. This font is freeware for personal, non-commercial use of any kind (including website decoration and so on). Contact me at sjohn@io.com if you're interested in a commercial license; rates will depend on the details.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0