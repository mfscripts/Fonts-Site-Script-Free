ROCKET YO-YO
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

Over Labor Day weekend, Sandra and I spent an evening drinking caffeinated stuff and doodling at the Little City Coffeehouse, and this was what I doodled that night. I didn't set out with any particular plan, but it ended up reminiscent of those fifties-advertisement-style typefaces I've seen around, with my own "handmade" twist. It's also sort of Halloweeny, in its way. It's a full keyboard set, ready to play.

This font is copyright 2001 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for personal, non-commercial use of any kind (including website decoration and so on). Contact me at sjohn@io.com if you're interested in a commercial license; rates will depend on the details.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0

