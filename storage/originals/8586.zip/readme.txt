TrueTypeFont: Mouser (Regular, Outline, Italic)
Dennis Ludlow 2001 all rights reserved
Sharkshock Productions
maddhatter_dl@yahoo.com

Hey there everyone. This is my first 3 part font series. Unlike most of my others, it looks great
in all caps. Good news for you IM users. Feel free to re-distribute this one for any non commercial
purpose. If you like the font, please email me simply let me know. Im a sucker for flattery :-) Take care everyone.
check out my graphic archive at www.sharkshock.uni.cc
                                  "because boring design SUCKS!"