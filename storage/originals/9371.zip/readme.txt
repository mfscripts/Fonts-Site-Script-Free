clearlight--------------------------------
http://swankarmy.net/clearlight


You may not use this font for any commercial projects
without telling me. It would also be nice of you to
send me a printout of what you used it on. I like to
see things like that. Plus, I might feel generous and
give you free stuff.

This font may not be redistributed in any format whatsoever.
I will not go into details. You know what is right and what
is wrong and what to ask me about.

thank me.
Brad


http://swankarmy.net/clearlight
clearlight--------------------------------
