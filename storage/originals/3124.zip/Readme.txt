Anonymous Fonts

Thank you for downloading Anonymous Fonts information folder/free sample fonts. The fonts Army Chalk, Juggernaut and Bleed are freeware. Permission, as always, is granted to freely distribute and/or post this font, providing that all files in the original archive are attached, including this one. Although offered as freeware, 'Army Chalk', 'Juggernaut' and 'Bleed' are protected by copyright, and may not be sampled, converted, or used to create new font files, without permission of the author.

Questions?
Please send questions, comments, bug reports and suggestions via Email to anonymous@kagi.com

