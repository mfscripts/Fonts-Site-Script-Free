TrueTypeFont: Air Millhouse (Regular)
Dennis Ludlow 2001 all rights reserved
Sharkshock Productions
maddhatter_dl@yahoo.com

Hey there everyone. Here's one of my last requested fonts before summer of '01
 This long awaited font has been months in planning but i finally took some time off and got it
done. Special thanks goes to my friend out there that submitted some vital EPS files that helped
me start this font. (you know who you are!). If you like the font, please email me simply let me know.
 Im a sucker for flattery :-) Take care everyone.
check out my graphic archive at www.sharkshock.uni.cc
                                  "because boring design SUCKS!"