This font may be freely distributed. free for all non-commercial uses.

Font family name 	: [ Kubra ]

Font Styles		: - Medium
			  - Hollow
			  - Extended
			  - Condensed
			  - Bold
			  - Low

Created by 		: Ersenak

Software 		: Fontlab 


To download the total package of Kubra fonts, please visit http:www.ersenak.f2s.com or email : ersenak@hotmail.com. For any questions or suggestions don't hesitate to contact,  if you use my font in a professional environment please notify.  This is a freeware font, donations are welcome. Regards Ersenak.
