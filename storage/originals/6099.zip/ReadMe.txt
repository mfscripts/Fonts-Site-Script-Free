SKUNTCH
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

I've played a bit with the ever-popular "stressed" approach to making a font, where you take a traditional typeface of some kind and make it look like it's been printed, scratched, faded, bloated, crumpled, discarded, abused and so on . . . and I've done a lot of hand-drawn, playful fonts, too. When I sat down to draw Skuntch, I was doing the latter in the mood for the former, so using a calligraphy marker, I drew a pre "stressed" hand-drawn font, letting it sort of decay towards the bottom and go jaggy all over, just kind of drawing as though I'd had too much caffeine (which is entirely possible; I was at Ruta Maya again).

So it's experimental, I suppose, but it's friendly. Skuntch is a full-keyboard set with extras (true dashes, curly quotes, and others), and now it's done! "Skuntch!"

This font is copyright 2001 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for personal, non-commercial use of any kind (including website decoration and so on). Contact me at sjohn@io.com if you're interested in a commercial license; rates will depend on the details.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 2.0
