SKULL SALAD
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

I'm not sure I can properly explain why Skull Salad is called "Skull Salad," so I'll just mention that I drew it at Ruta Maya, one of my favorite spots in all of Austin (you can catch a brief glimpse of it in Spy Kids if you look close enough) and inspiration for "Ela's Tomb" in Points in Space. I drew it on my standard font template, using my trusty Sharpie. I doodle fonts sort of like Skull Salad all the time as finger-limberers, but something about the shapes "clicked" (and rattled, and scuttled) for me that day, so I kept it, named it, and gave it digital life. It's a full-keyboard set with extras, and now it's yours.

This font is freeware for any private, non-commercial use; distribute it all you like, as long as it remains free! For permission/license for commercial use, email sjohn@cumberlandgames.com

Version 1.0