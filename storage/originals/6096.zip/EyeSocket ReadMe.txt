EYE SOCKET
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

This is another "funky Sharpie" font that feels like a kind of "cousin" to Skull Salad. Eye Socket a bit wilder than the cousin, though, and sports both uppercase and lowercase (as well as the usual full-keyboard support and a few extended-set extras).

And, as with Skull Salad, I'm not sure what the heck Eye Socket means except that it's fun to draw. I'm also very happy with the way the vectors came out on this one; I did a lot of tweaking and massaging to get them nice and clean without losing the strokes of the pen. I'll probably revisit this style again a few more times before I've exhausted my interest in it (and/or the ink in my Sharpie) . . .

Version 1.0

This font is copyright 2002 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for personal, non-commercial use of any kind (including website decoration and so on). Contact me at sjohn@io.com if you're interested in a commercial license; rates will depend on the details.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.