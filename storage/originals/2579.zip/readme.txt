TrueTypeFont: Blockbusted
Dennis Ludlow Productions 2000 all rights reserved
Sharkshock Productions

3 years ago i rented Batman Forever at Blockbuster. I went back a few weeks ago
for the first time since then and found out i had a late fee that exceeded $75 and that the
they went through a collections agency to retreive the funds rather than just charge my credit
card. To this day, i swear i dropped that thing off. Anyway, here's a simple but sweet one entiteled
Blockbusted. hope you enjoy.

check out my graphic archive at www.sharkshock.uni.cc
                                  "because boring design SUCKS!"