The fonts included in this package were made in celebration of the honorary doctorate Dr. Luc Devroye recently received in Belgium. Luc was born in Tienen, Belgium. He obtained a Ph.D. degree from the University of Texas in 1976, and since then has been a professor of Computer Science at McGill University in Montreal, Canada. He is also an associate member of the Department of Mathematics and Statistics there. Dr. Devroye is married and has 2 daughters.

Luc's favourite pastime is the reason we are celebrating with him. Luc is a typography fan, if not THE typography fan. I emphasize this because Luc shares his passion with everyone who is interested, via his site, hosted on McGill University's servers. Luc's site, appropriately named 'On Snot and Fonts' is the proverbial starting point for anything type-related. It gets 12,000 hits a day, has not a single advertisement on it, and accommodates all levels of typographical curiosities. You can visit for yourself at:
http://cgm.cs.mcgill.ca/~luc/fonts.html

I have known Luc for several years now. I can without hesitation say that the man is my favourite Canadian. 

If you like the fonts included here, pour yourself a glass of wine, lift it up in the air and say: "Here's to you, Luc!"

'
