COCK BOAT
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

"You can name it anything you like," I said. Amy "Rogue" Miles, my sister-in-spirit from back east in Virginia, was visiting Sandra and I in Texas and so, naturally, I had her "working in the font mines," doodling letters and even drawing a (very cool) Spark for the Scrapbook. She had drawn the wild and eclectic set of characters that make up Cock Boat (a full keyboard caps set with a few extras thrown in) but hadn't yet named it. We were at the 503 Coffee Bar at the time, and Amy had drawn the masters with a Sharpie. She wouldn't hit on the perfect name 'til later that evening.

Apparently, the phrase "Here comes the cock boat!" was used in an off-color Dilbert parody online somewhere, and Rogue had found the term charming. So here we are, with a font to carry it into the digital eternity. Share it with your family; I'll be sharing it with mine. 

This font is freeware for any private or commercial use; distribute it all you like, as long as it remains free - It's not for sale! Enjoy!

Version 1.0