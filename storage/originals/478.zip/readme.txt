Freeware font. 
copyright � Ouripedes Gallene 2003.