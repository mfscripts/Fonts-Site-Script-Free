Chapultepec is freeware.
Copyright 2000 Joanne W. Kline; all rights reserved.

This font file is freeware and is royalty-free for non-commercial use.  You may use it to create commercial images or documents but the font file itself may not be included in any collection offered for sale or as part of any commercial software package without my express permission.  You may distribute this file free by itself (such as for download on your website) as long as it is accompanied by this readme file.

For more information on purchasing a commercial license email to:
snerk@ingonyama.com

Please visit http://www.ingonyama.com/ for more free stuff.

Joanne Kline
Ingonyama



