Kindy.ttf

This font was designed by Nick Kind in November 2001.

Feel free to use this for you own use. Anyone using for commercial use - be nice to let me know!

There is no fee for using or downloading this font.

Big Up!

www.nickkind.co.uk

fonts@nickkind.co.uk