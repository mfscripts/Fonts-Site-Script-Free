This font is papertrail (shareware)
made by SnatchSoft font foundry.

http://members.xoom.com/snatchsoft