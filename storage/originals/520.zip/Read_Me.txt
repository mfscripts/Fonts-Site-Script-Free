><><><><><><><>><><><><><><><><><><><><><><><

Czcionka ANTIBIOTECH jest mojego autorstwa,
zawiera du�e litery, cyfry
oraz niekt�re znaki interpunkcyjne.

Mo�esz j� wykorzystywa�
do prywatnych produkcji,
je�li chcesz j� u�y� do projekt�w
komercyjnych to prosz� o kontakt.

Czcionk� mo�na udost�pnia� 
pod warunkiem, �e b�dzie za darmo
i razem z tym plikiem informacyjnym.

Mam nadziej�, �e ANTIBIOTECH
spodoba Ci si� i b�dzie przydatna :)

---------------------------------------------

The font ANTIBIOTECH that was designed by me,
contains large letters, digits
and some punctuations.

It's freeware.
You can use it in your private projects,
if you want to put it to the commercial
projects please let me know.

font can be redistributed in condition
that it will be free of charge 
and with this readme file attached.

Hope you like ANTIBIOTECH and it will be
useful in your work :)

---------------------------------------------

respect to: barme >>> www.czcionki.com <<<

                             Gulash
gulash@tgi.com.pl

><><><><><><><>><><><><><><><><><><><><><><><