Gravicon Display - Macintosh Type 1/Truetype
Final Release - October 1996
Copyright � 1993, 1996 by Tom C. Lai.
All Rights Reserved
See end of document for terms of use.

**********
Table of Contents:

* Introduction
* Pricing
* Installing the Software
* Paying the Shareware Fee
* FAQ
* Contact Information
* Terms of Use

**********
Introduction:

Gravicon Display is a heavy weight modern font, based on a stencil theme,
fairly futuristic looking - think of those sci-fi wall stencils in film and
TV productions.  It is very compact, and is best used a larger point sizes.
It has a full character set, a few dead characters, a set of symbols, and
a few alternate characters (option-character).  The two alternate
characters are A and V.

This is the final release version, so if you have already paid for a
previous version, you are automatically registered for this version.  There
have been significant changes to the spacing and kerning of characters - so
be aware that existing layouts may require reworking.  Windows (Type 1 and
Truetype) versions are now available.  I am no longer using cityfox@aol.com
as an address - please direct your mail to tclai@kagi.com.

If you use this font for 30 days or more, either erase the font or pay the
shareware fee.  That's it.  For more do�s and don'ts, please read the user
agreement at the end of this document.

**********
Pricing:

For new users, the pricing is as follows:

Single User Licenses
--------------------
$15 per copy (non-commercial)
$20 per copy (commercial)

Non-commercial encompasses non-profit divisions of educational
institutions, shareware/freeware authors, students, and users purchasing
this font for personal use.  If you have a specific question on where you
fit, e-mail me.

Site License
------------
$300 per site

A Site License covers one specific location for your organization. One big
advantage of a Site License is that you don't need to keep track of how
many people at your site are using this font.   A site is defined as
everything within a 100mi/160km radius of your main location.

Worldwide License
-----------------
$1200 for all locations

A World-Wide License covers all locations for your organization.

**********
Installing the Software:

Type 1 Version
--------------
If you have Adobe Type Manager(tm) installed, go to the ATM Control Panel
and open it by double-clicking on the icon.  Select the Add� button and
pick Gravicon-Display out of the directory where you unzipped the archive.

If you do not have Adobe Type Manager installed, you will probably want to
use the TrueType version instead.

TrueType Version
----------------
Open up your control panel and select the Fonts icon.  Open up the Fonts
window and use the Add... button to select Gravicon-Display (TrueType) out of
the directory where you unzipped the archive.  Click OK.  Windows should
now have installed the TrueType version of Gravicon-Display.

If TrueType is not already enabled, click on the TrueType... button to
bring up a window.  Check the box next to Enable TrueType Fonts to activate
TrueType within your applications.

**********
Paying the Shareware Fee:

Starting August of 1996, all payments will by handled by Kagi Shareware,
the same business that processes payments for shareware authors like Peter
N. Lewis (author of NetPresenz, formerly FTPd, Anarchie, and others.)

Using the Register Program
-------------------------
To pay the registration fee, open the Register program that was included
with AmarilloUSAF. Enter your name, your email address, and the number of
single user licenses you desire for each program you wish to purchase (or
Site or Word-Wide licenses).  Please check the box for non-commercial (ie,
in-house, personal, academic) or commercial license.

You can Save, Copy, or Print the data from the Register program and send
the data and payment to Kagi via e-mail, regular mail, or by fax.  Payment
options include Cash, Check, Credit Card, and First Virtual.  Checks should
be drawn in US Dollars.  To e-mail a payment, use the copy button and paste
the form into an e-mail message to <shareware@kagi.com>.  Other payment
methods will require printing or saving directly from the program (ie fax,
or postal mail.)  More instructions are contained within the actual
Register program, and balloon help is available.

Payments sent via email are processed within 3 to 4 days. You will receive
an email acknowledgement when it is processed (so please put your e-mail
address down!)  Payments sent via fax take up to 10 days and if you provide
a correct internet email address you will receive an email acknowledgement.
Your postal address is not required, but you are strongly urged to include
it so that I have a complete record of your registration.

Registering via the World Wide Web
--------------------------------
If you are using Visa, MasterCard, or American Express, you can use Kagi's
online order processing.  Visit the TLai Enterprises website at
<http://www.kagi.com/authors/tclai/> to find out more.


If You Need A Purchase Order
---------------------------
If you have a purchasing department, you can enter all the data into the
Register program and then select Invoice as your payment method. Print
three copies of the form and send it to your accounts payable people. You
might want to highlight the line that mentions that they must include a
copy of the form with their payment. Kagi can not invoice your company, you
need to act on my behalf and generate the invoice and handle all the
paperwork on your end.

**********
Gravicon FAQ:

1. >Can I give copies of this font to friends and/or colleagues?<
2. >Do you have a version for Unix/Windows/Macintosh in Truetype/Type 1?<
3. >There's a problem with the letters jk/etc., can you fix it?<
4. >The text isn't coming out right/I'm getting garbage!<
5. >The text is all jagged on the screen - what's the problem?<
6. >There's this COOL new movie with a killer font - can you make it for me?<
7. >Can you do a custom font?<
8. >Do you take Credit Card/Check/Cash?<
9. >I sent in my money and haven't heard any word from you.  What gives?<

----------

1. >Can I give copies of this font to friends and/or colleagues?<

Yes, but be sure to give them the *entire* archive, not just the font file.
Orphaned copies of fonts who were separated from their ReadMes are
floating about everywhere, and it isn't quite fair to their authors when
the users don't know who to send the shareware fee to.  Also, please do not
recompress archives or rebundle them - contact me if there is a specific
need to do so.

2. >Do you have a version for Unix/Windows/Macintosh in Truetype/Type 1?<

I have Type 1 and Truetype for both Macintosh and Windows.  If you have
problems with either, or need another version, send me e-mail and I'll see
what I can do.  Please do NOT port to other platforms!  If a port is
necessary, please contact me.

3. >There's a problem with the letters jk/etc., can you fix it?<

If you have very large kerning gaps, or letters that run into each other,
you may have a bootleg version of Gravicon.  The current one is dated
October of 1996 - the first revision for Windows.  Please update to
the correct version.

4. >The text isn't coming out right/I'm getting garbage!<

First of all, check to see if this is a problem specific to Gravicon, and
whether or not it appears in other programs.  Due to inconsistencies
between implementations under Windows, typefaces ported from other
platforms may not function correctly under all programs.  If that is the
case, and you have ruled out all other causes, please drop me a bug report
at tclai@kagi.com.

5. >The text is all jagged on the screen - what's the problem?<

Make sure that TrueType/ATM is enabled, and that all the proper parts of
the font are in place and intact.  If any portion of the font has been
corrupted (due to a drive crash, virus, etc.), it may be necessary to
re-install the font to restore proper operation.

6. >There's this COOL new movie with a killer font - can you make it for me?<

I don't take requests based on other material - it's a lot of work to
create a typeface and by the time I finish, people are usually disraught
over the time that it's taken.  I will do commissions, but that's a matter
that needs to be discussed with the customer.

7. >Can you do a custom font?<

See above.

8. >Do you take Credit Card/Check/Cash?<

Just make sure it's in US dollars - use the Register application to
automate the process and send the results to Kagi shareware.

9. >I sent in my money and haven't heard any word from you.  What gives?<

While I try to send a thank-you note to everyone who sends in a shareware
payment, it's usually impractical, given that I'm student on a tight
schedule.  By the time I get around to answering my mail, it's a few weeks
at the least, a month or two at the most which is why Kagi is now handling
my payment processing.  If you included an e-mail address, you will get an
e-mail confirmation.  If you don't, drop me a note and I'll look into it.

**********
Contact Information:

(correspondence only)
TLai Enterprises
10719 Ashby Ave.
Los Angeles, CA 90064-3210
tclai@kagi.com
http://www.kagi.com/authors/tclai/

(send all payments to)
Kagi
1442-A Walnut Street #392-TB
Berkeley, California 94709-1405 USA
510 652-6589 FAX
shareware@kagi.com

**********
Terms of Use:

By using this font, you accept and agree to the conditions as set forth in
this agreement.

YOU CAN:

Distribute the original archive to any friends or non-commercial electronic
information services.  Use each registered copy on one machine at a time.
Install a copy on a network, provided that the number of machines using the
font at one time does not exceed the number of registered copies (purchase
a site license to avoid the need to track each copy.)  Send more money if
you feel like it, and/or feedback, where this font will be used, etc.

YOU CANNOT:

Distribute this product commercially without express written consent of
author.  Translate or create derivative works based upon this software.
Sub-license, sell, rent, lend, or lease any part of the software.  Remove,
replace, obscure, or alter any documentation or copyright notices contained
within the archive or the software itself.  Distribute this software in
anything other than the original archive.  Distribute this software without
the original documentation.  Reverse engineer, decompile, or disassemble
this software.
----------------

TC Lai
October 21, 1996

This typeface was designed on a MacOS computer.  Send email to:
<evangelist@macway.com> or go to: <http://www.evangelist.macaddict.com/> to
find out more!