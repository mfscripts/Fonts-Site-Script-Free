"Triad XS"  -  a Dealer Quality TrueType Font
 (c) 2000 by ck!  [Freaky Fonts]

The personal, non-commercial use of my font is free.
But Donations are accepted and highly appreciated!
The use of my fonts for commercial and profit purposes is prohibited,
unless a small donation is send to me.
Contact: ckrule@geocities.com
These font files may not be modified or renamed.
This readme file must be included with each font, unchanged.
Redistribute? Sure, but send me an e-mail.

If you like the font, please e-mail: 
ckrule@geocities.com

Visit ..::Freaky Fonts::.. for updates and new fonts (PC & MAC) :
http://come.to/freakyfonts
http://www.geocities.com/Area51/Shadowlands/7677/

Thanks to {ths} for the MAC conversion.
ths@higoto.de or visit: http://www.higoto.de/ths

Note:
There are  triangles mapped to: � � � �
Why is this font called "Triad"? Visit:
http://www.triad.c64.org