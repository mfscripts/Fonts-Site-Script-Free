THE ALCHEMIST
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

Like "Pigeon Street" (see the main Fontworks page), The Alchemist is a font I drew with a particular character in mind - the spindly, mantis-like figure who appears briefly in Ring of Thieves. In truth, he's one of a small stable of "character actors" I use in many fantasy games, a favorite NPC to resurrect for a cameo now and again.

So, this is how he writes. This font includes more glyphs than just about any other I've done - a full keyboard set plus an oddball smattering of extended characters. I'll probably fix a few things (like the too-faint period) before archiving it on the Fontworks, but I like it enough to do so even if nobody emails me about this one. Enjoy!

This font is copyright 2001 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for personal, non-commercial use of any kind (including website decoration and so on). Contact me at sjohn@io.com if you're interested in a commercial license; rates will depend on the details.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Download Ring of Thieves (mentioned above) for free from
www.io.com/~sjohn/thieves.htm

Version 2.0

This version adds some additional foreign characters (added for a client in Norway) and extensive additional kerning.

