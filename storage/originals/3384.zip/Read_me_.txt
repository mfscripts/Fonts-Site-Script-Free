She's a sweet southern California housewife who can match wits with any former child star and may or may not be on acid but is definitely more than a little confused about the estate of her late lover, Pierce Inverarity.  

Oedipa is the much cooler (well, my humble opinion) companion to Pierce Inverarity. I created this face for dummy spec pages I designed for Thomas Pynchon's intriguing satirical novel, The Crying of Lot 49. There's three other faces in my Trystero collection -- Baby Igor, W.A.S.T.E., and Mucho... they'll be here soon.

This face is best described as a housewife on acid, doodling on a desktop because maybe she's bored or maybe she's communicating in secret code. It's kind of like the writing that you'd use in junior high, when you dreamed in math class and doodled the name of your dearly beloved over and over, with all the appropriate hormonal embellishments.

There's 26 caps, 26 lower cases, all the numbers and punctuation and special characters you'll ever need, and the W.A.S.T.E. logo to add an air of acid-trip mystique to your favorite desktop publishing/word processing project.

This typeface is shareware, so if you like it and use it and want to get into Heaven, send a measly five bucks to:
K. Morgan Herzog
14616 Hanover Lane
St. Paul, MN  55124