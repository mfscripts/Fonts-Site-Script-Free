Please visit my site!
http://www.geocities.com/dfonts2000/
feel free to distribute this font as long as you include this readme file. 
Thanx, enjoy the font!