Screwball computer font �2000 Harold Lohner

Offered as freeware in memory of MADELINE KAHN.

Please send a contribution in her name to:
The Ovarian Cancer Research Fund, Inc.
One Pennsylvania Plaza
Suite 1610
New York, NY 10119-0165.

Based on the hand-lettered titles (by The Golds West, 
Inc.) of the movie "What's Up, Doc?", produced and directed 
by Peter Bogdanovich.

HLohner@aol.com
http://members.aol.com/fontner