Kiwi Media Presents...

DEVOTION
a truetype font for Windows(tm).

   This font is based off of the brushstroke handwriting of Anton Corbijn, 
who designed the cover of Depeche Mode's latest "Songs of Faith and 
Devotion."   Each letter was created by scanning, tracing, and importing 
from the album cover (with a few minor exceptions...there was no "q", "x", 
or "b".  I kinda had to wing it)


1)  WHAT'S THIS ALL ABOUT?
      Ok, I got into a minor fervor after seeing Mode live in Milwaukee.  
So I hit the nearest scanner and whipped out Fontmonger (yes,  
Fontmonger...I couldn't afford anything more powerful than that at the time).  
This intends to approximate as closely as possible the writing that has 
pervaded the covers of CDs and singles.  I've since cleaned it up with 
fontographer  

2) CHARACTER MAPS
    everything is where it should be, with a few minor exceptions.  There 
are two kinds of capital for every letter, one mapped to the letter and 
one to shift-letter.   This is because Corbijn for the most part didn't 
use small letters anywhere except in the word "depeche" on the singles. 
The small letters for "depeche" can be found someplace in the character set 
characters, but I really don't know where because I've got a lousy 
windows keymap utility. # has been replaced by the english monetary pound symbol, and most other 
shift numericals produce "D" and "M" in a box, a la "D" and "M" on the SoFaD CD
cover.   The bracket keys { } [ ] produce "icons" derived from the purple paint
 swashes also on the cover.  tilde produces a DM logo. 

3)  WHAT'S IN IT FOR ME?
    I'm hoping that other DM fans will like this.   I'm also hoping 
someone will send me money for this.  $5 american would be nice, as I put 
a lot of effort into this.  If you can't afford it, send me some email.  I 
also appreciate info about all sorts of music, bootleg CD's,  etc.  
Whatever you can manage.  Contact me via email to get my latest snailmail 
address.

Here's the address:
wonko@dax.cs.wisc.edu

4) LEGALESE
     Kiwi Media Ltd. is my own little fabrication, dating back to some 
Apple ][ stuff I did in the mid 80's.  I actually predate Kiwi Software, 
with which I have absolutely no connection.  Anyway, this font may be 
distributed freely, as long as it is not modified without my permission.   
I'd like to get credit for my work...

5) Revision History

1.0 released November 1993.  Original release.
1.0w First Windows release, December 1993.

1.01w Fixed a bug in the Windows translation.  (forgot to strip the 
					Mac resources).
1.1  Fixed a line height problem with some of the mac characters.  
  				Got Fontographer so I could get some real stuff done. 
1.5  Got the characters to have proper ascent and descent on the mac.
2.0w Changed some character maps under windows, added some characters, 
just generally fixed the hell out of it. 
 
Enjoy!

Eric Oehler  
