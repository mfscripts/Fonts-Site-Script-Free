DS Eraser Cyr (Eraser - old)
----------------------------------------------
D-Studio (Moscow) & Blackboard Etiquette.(USA)
(c)1997-98, All rights reserved.
Freeware version.

* * * * * * * * * * * * * * * * * * * * * * * *

Feel free to share this font with others,
but please include this documentation.

Thanks,

Nikolay and Peter


* * * * * * * * * * * * * * * * * * * * * * * *

D-Studio (Moscow)
http://wt.aha.ru/d-studio/
webart@tomcat.ru
Dubina Nikolay

* * * * * * * * * * * * * * * * * * * * * * * *

Blackboard Etiquette.(USA)
http://www.ar.com.au/~bbetiq/
Peter Stanton