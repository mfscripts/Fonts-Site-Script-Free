"Mad a Fraf" Truetype Font 
(c) 2005 by Croisot Damien 

Cette fonte est en utilisation gratuite pour un usage uniquement personnel. 
Toute autre utilisation qu'elles soit � but lucratif ou non est interdite sans l'accord express�ment �crit de l'auteur. 
Cette fonte ne peut �tre modifi�e et ce fichier de readme doit �tre inclus avec le zip qui la contient. 
Pour contacter l'auteur : croisot.dam-AT-gmail.com 
Mad_a_Fraf.ttf a �t� distribu�e sur le site Dafont.com en Aout 2005 

------------------------------------------------------------------------ 

"Mad a Fraf" Truetype Font 
(c) 2005 by Croisot Damien 

This font is free for personal use only. 
Any other use (commercial or not) is strictly prohibited without the written agreement of the author. 
This font cannot be modified and this ReadMe file must always be included in the zip. 
To contact the author: croisot.dam-AT-gmail.com 
Mad_a_Fraf.ttf was distributed on Dafont.com in August 2005 