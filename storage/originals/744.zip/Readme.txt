BAJO LA LUNA PRODUCCIONES
"Thank You For The Venom" TrueType Font
Version 1.0. August 13, 2005

Thanks for downloading this font!

Thank you for downloading this Bajo La Luna font. This font is freeware, and you may use it in whatever form you want (see License). To get the latest version of this font, visit my website at:

http://www.bajo-la-luna.com
http://gatoenlaluna.deviantart.com

Software License

By downloading, installing or using the archive, you confirm your agreement in this license.

I. Dedication
This font (just like everything I do in my life) is dedicated to my beloved girl, Lili�n (a.k.a. Luna). She is my inspiration, the light and love of my life. I wouldn�t know what to do without her by my side. I love you so much, my beautiful Luna!

II. Freeware
This font is distributed as freeware. This means that I grant you the license to use it as much as you like (see Limitations). But if you like it, I ask only two things of you: say a prayer for me (and Luna while you're at it) to your God - or whatever you believe in - and wish us some luck.

III. Limitations

A. Reverse Engineering
Reverse Engineering is not allowed as with nearly any software, so this should be no surprise.

B. Warranty
Bajo La Luna Producciones gives you the only warranty that no code was placed to cause intentional harm to your system. However, I can give you no warranty that your work with my font will be uninterrupted and error-free.

C. Liability
Under no circumstances can you make me liable for any damage, however caused, including, but not limited to damage you might do to your system using my software.

D. Modifications
You may not modify, adapt, translate, decompile, disassemble, or create derivative works based on the product without prior written consent from Bajo La Luna Producciones.

IV. Distribution
Here are some basic rules about distributing my font.

A. Private Distribution
You may give away single copies of the software as long as you don't modify this license or other files of the archive.

B. Mirroring
If you want to mirror this font, feel free to do so as long as you don't modify the original archive. If you want to be kept up to date about major updates, check the Aenigmate Productions website.

C. Publishing
You may publish this font in a book or magazine (or other media) by simply sending a written request for permission, including a description of your specific needs. I request only to be proper credited as the author.

If you redistribute my font in any way, I'd like you to place a link to my website or deviantART account on your website, and please drop me a line. I like to know where my fonts are ;-)

All contents of this package Copyright 2005, Bajo La Luna Producciones

If you have any questions concerning this License, or if you desire to contact Bajo La Luna Producciones for any reason, please write to:

thecat@bajo-la-luna.com

or visit us online at:

http://www.bajo-la-luna.com
http://gatoenlaluna.deviantart.com

Good luck, and blessings!
)O(The Cat)O(
Bajo La Luna Producciones
M�xico

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
BAJO LA LUNA PRODUCCIONES
Fuente TrueType "Thank You For The Venom"
Versi�n 1.0. Agosto 13, 2005

�Gracias por descargar esta fuente!

Gracias por descargar esta fuente hecha por Bajo La Luna Producciones. Esta fuente es freeware, y puedes usarla de la forma que quieras (ver Licencia). Para obtener la versi�n
m�s reciente, visita mi sitio web en:

http://www.bajo-la-luna.com
http://gatoenlaluna.deviantart.com

Licencia de Software

Al descargar, instalar o usar este archivo, confirmas tu aceptaci�n de esta licencia.

I. Dedicatoria

Esta fuente est� dedicada (como todo lo que hago en mi vida) a mi ni�a amada, Lili�n (alias Luna). Ella es mi inspiraci�n, la luz y el amor de mi vida. No sabr�a que hacer sin ella a mi lado. Te quiero much�simo, mi preciosa Luna!

II. Freeware
Esta fuente se distribuye como freeware. Esto significa que te otorgo la licencia para usarla tanto como quieras (ver Limitaciones). Pero si te gusta, te pido s�lo dos cosas: di una oraci�n por m� (y por Luna ya que est�s en ello) a tu Dios - o en lo que sea que creas � y des�anos algo de suerte.

III. Limitaciones

A. Ingenier�a Inversa
La Ingenier�a Inversa no est� permitida en casi cualquier software, por lo que esto no debe ser sorpresa.

B. Garant�a
Bajo La Luna Producciones te da la �nica garant�a de que no se puso ning�n c�digo para causar da�o a tu sistema. De cualquier forma, no garantizo que tu trabajo con mi fuente ser� ininterrumpido y libre de errores.

C. Responsabilidad Legal
Bajo ninguna circunstancia puedes hacerme legalmente responsable por cualquier da�o, como quiera que sea causado, incluyendo, pero no limitado a da�o que puedas hacerle a tu sistema utilizando mi software.

D. Modificaciones
No puedes modificar, adaptar, trasladar, descompilar, desensamblar o crear trabajos derivados basados en el producto sin previo consentimiento de Bajo La Luna Producciones.

IV. Distribuci�n
Aqu� hay algunas reglas b�sicas sobre la distribuci�n de mi fuente.

A. Distribuci�n Privada
Puedes distribuir copias del software siempre que no modifiques esta licencia u otros archivos en el paquete.

B. Servidores Espejo (Mirroring)
Si quieres poner en un servidor espejo (mirroring) esta fuente, puedes hacerlo mientras no modifiques el archivo original. Si quieres informaci�n sobre actualizaciones, visita el sitio de Bajo La Luna Producciones. 

C. Publicaci�n
Puedes publicar esta fuente en un libro, revista u otro medio enviando una solicitud de permiso por escrito, incluyendo una descripci�n de tus necesidades espec�ficas. S�lo pido que me des el cr�dito como autor.

Si redistribuyes mi fuente por cualquier medio, me gustar�a que pusieras un link hacia mi sitio web o mi cuenta de deviantART, y por favor avisame. Me gusta saber d�nde est�n mis fuentes ;-)

Todo el contenido de este archivo Copyright 2005, Bajo La Luna Producciones

Si tienes alguna pregunta acerca de esta Licencia, o si deseas contactar a Bajo La Luna Producciones por cualquier raz�n, por favor escribe a:

thecat@bajo-la-luna.com

o vis�tanos en:

http://www.bajo-la-luna.com
http://gatoenlaluna.deviantart.com

Suerte, y bendiciones!
)O(The Cat)O(
Bajo La Luna Producciones
M�xico