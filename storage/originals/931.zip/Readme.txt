This is my very first font.
Based on my own hand writing.
Hope you enjoy it, and please
register at 
www.thegraphicsforum.com
For more fonts and other
graphics.


Blade
www.thegraphicsforum.com

Dewald Hein