DSMotterHo
----------------------------------------------
D-Studio (Moscow)
(c)1997-99, All rights reserved.
Freeware version.

* * * * * * * * * * * * * * * * * * * * * * * *

Feel free to share this font with others,
but please include this documentation.

Thanks,

Nikolay


* * * * * * * * * * * * * * * * * * * * * * * *

D-Studio (Moscow)
http://wt.aha.ru/d-studio/
webart@tomcat.ru
Dubina Nikolay