Thanks for downloading 32 pages. Use it for whatever you like, it's free. Distribute it freely.

32 pages is a monospaced, below-128 font. All the letters are different, and there are no two dots that are the same. If you need other characters, you can email me and we'll work something out.

Darko Stanicic
darone@sezampro.yu
