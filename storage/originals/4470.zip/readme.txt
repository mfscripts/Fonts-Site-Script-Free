This font is copyright ISABELLE TROLIO.

It is FREEWARE and you can distribute it anywhere and how you please as long as you include this file and notify me when you do so.

e-mail: isabelle-@altavista.net 
write: PO Box 8150, Subiaco East WA 6008, Australia.