My Type of Font - Nov 20th 2000

1001 Free Fonts - Jason Nolan

This font is 100% freeware and may be distributed as long as this readme file is attached.

JasonNolan@aol.com

PS : Special thanks to Dan at http://www.iconian.com for his much needed help.