                           Reverb v3.1�1995 by Rafael Dinner

This is the fifth release of the Reverb font.  Version history:
�Reverb 1.0: many bugs, including missing segments of letters
�Reverb 2.0: major bugs fixed in the Type 1 font, but the TrueType had 
	path direction problems
�Reverb 2.1: fixed TrueType path directions, spacing, kerning
�Reverb 3.0: adjusted paths so that white lines appear in black parts, 
	black lines are more distinct
�Reverb 3.1: released complete shareware font rather than partial 
	DemoWare font
The font including all caps + some punctuation costs only $5 (US dollars, no foreign checks, please!), which does not exceed anyone's capacities. Furthermore, I feel that this font is high quality (all of my fonts are created in Adobe Illustrator with maximum accuracy), and there is always the possibility that I will raise the price when another version comes out. Payment now, however, covers all future versions. Feel free to give suggestions (no purchase necessary!) and request bitmap sizes.

Contact me at school:
mail:
500 Memorial Dr.
Cambridge, MA 02139

email:
rdinner@mit.edu

HTTP (browse and download my other fonts):
http://web.mit.edu/rdinner/www/

Reverb is available in Postscript� Type 1 and TrueType�. :-)

Reverb is meant to be a 3-D display font to grab attention or just look slick. You may also like using it in italics. You will find that Reverb maintains accuracy at very high resolutions, and does so with minimum complexity of paths (=minimum disk space and RAM needed).

Here is a list of my currently completed fonts:
ArgentumBlack, ArgentumWhite, ArgentumShine
ArgentumSilver (type 3 postscript)
Daisy
Diamond
Grease
Kontrast
Reverb
RotondoSilver
StilettoBlack, StilettoSilver

I also plan on releasing other display typefaces, ranging from calligraphic to futuristic. Send me requests. Enjoy Reverb!