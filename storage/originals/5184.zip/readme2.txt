BorderPic's is an incredible font.  It takes only 30K of memory yet 
allows you to create literally hindreds of different horizontal 
borders in your document merely by changing the font!  From 
footprints to chains to all sorts of zigs and zags, you can 
combine the keystrokes to form many different fun or formal 
borders.  Chnge the following section to BorderPics to see what 
it looks like.  I recommend changing the font size to at least 
20 points.

BBBBBC BC C DDDDE DE E FGGGGG FFFFFFF IIII JJJJJJ KKKKKKKK LLLL MMMMMM NNNNNNNN PPPPP QRQRQR STSTST VVVVVVV WWWWWWW XYYYYZ  abbbbbb aaaaaaaa c c c c  d d d d d   cdcdcdcdcdcdcdcd  eee ffff efefefe ghghghghg jiiiiiij kllllm nnnooononononon pppp qqqq pqpqpqpqpqpqpqpqp  rrrr tttttt uuuuuu vvvvvv wxxxxxxx zzzzzzzz !!!!!!!% @@@@^ ######% $$$$$^ !@#$*& 12323145456767676171171131234111411511411 8899 898  89898989898  000000 -=-=-=[][][][][]  [[[[]]]] ;;;;; '''' ,.,.,.,,,,.... ...,,, /////////// A

Now that you have seen what it can do let me tell you more about 
the font.  It is freeware and may be distributed UNALTERED for free.  
I, Raffi Kojian hold the copyright however and reserve all rights.  
Do not alter the font without written permission from myself.
Do not redistribute font without this file.

This font is dedicated to the victims of the Armenian Genocide, 
which explains the TURKEY=GENOCIDE  appearing several times in the 
font.  The Turkish government murdered over half its Armenian 
citizens and expelled almost all of the rest from the land which 
they had continually inhabited for 3 thousand years.  This is one 
of the darkest chapters in human history and should never be forgotten.

My e-mail is currently kojian@ix.netcom.com and my homepage is 
currently http://www.netcom.com/~kojian where you can find more 
info on the Armenian Genocide if you wish.

10/96