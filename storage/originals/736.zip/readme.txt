Copyright 2005 Amy VanTorre.

All use is free.

Created using Adobe Photoshop 7 and Corel Painter 9.

\,| and ~  create a space with a grunge spatter. { and } make a spatter on the letter you've just typed.





KiraLynn is dedicated to the real KiraLynn. Happy birthday. =)