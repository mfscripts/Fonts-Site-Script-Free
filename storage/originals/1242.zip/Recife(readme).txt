This font was created by Eduardo Recife.
Its a freeware typeface, so you can share it
with other people and use it for free. 

I used to belong to Atrophy Fonts, and later on
Misprinted Type, both created by me. They are gone!

These are not fancy and pretty looking fonts, these
are weird looking typefaces, cus Im really tired 
about using all these pretty fonts at my work. 

This font is copyrighted by ME, so dont change the
font look or info and of course dont charge for it.

I would like to hear comments or suggestions about
my fonts, so please email me: recife@gold.com.br

Enjoy!
Recife
