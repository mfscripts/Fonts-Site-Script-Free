DS Comedy Cyr (Odishi - old)
----------------------------------------------
D-Studio (Moscow) & Digital Empires Inc.(USA)
(c)1997-98, All rights reserved.
Freeware version.

* * * * * * * * * * * * * * * * * * * * * * * *

DS Comedy Cyr (Odishi (TM) - old) is shareware. If you like, keep it,
and use this font, please check out our web page at
wt.aha.ru/d-studio or WWW.DigitalEmpires.com for pricing (the font
will probably never be more than $10).

Feel free to share this font with others,
but please include this documentation.

Thanks,

Nikolay and Steve


* * * * * * * * * * * * * * * * * * * * * * * *

D-Studio (Moscow)
http://wt.aha.ru/d-studio/
webart@tomcat.ru
Dubina Nikolay

* * * * * * * * * * * * * * * * * * * * * * * *

Digital Empires Inc.(USA)
http://www.DigitalEmpires.com/
Webmaster@DigitalEmpires.com
Steve