TrueTypeFont: Mobsters
Dennis Ludlow 2001 all rights reserved
Sharkshock Productions

Hey there mafia lovers. This font has got it all! You can smell the Ragu bubbling on the stove
top from next door. If this doesnt scream Italian gun slingin, then rustle my hair and call me
Mustafa. The lowercase "r" and  capitals "J" and "L" spell out a gun for your viewing pleasure.
Feel free to re-distribute as always, but only as long as this readme file stays intact.
check out my graphic archive at www.sharkshock.uni.cc
                                  "because boring design SUCKS!"