RISUS LCB DINGBATS
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

Risus LCB Dingbats is the font I used to "illustrate" the Risus Version 1.5 Acrobat file! I created it from hand-drawn master samples. This approach to line-art in page layout (the font approach, I mean, not the stick-figure approach) reduces file size, insures scalability for any home printer, and (best of all) lets me color the line art purple if I feel like it, with the flick of a mouse.

Risus is "Risus: The Anything RPG" my freeware game for brain-lite roleplaying. You can read more about it (and download the Risus 1.5 PDF) by visiting www.cumberlandgames.com -- I've included a plaintext version of Risus in this archive to get you started!

=====================================================================

This font is copyright 2001 by S. John Ross. "Risus: The Anything RPG" and "Cumberland Games & Diversions" are trademarks of S. John Ross. This font is freeware for personal, non-commercial use of any kind (including website decoration and so on, but not including document-embedding). Contact me at sjohn@io.com if you're interested in a commercial license; rates will depend on the details.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.1