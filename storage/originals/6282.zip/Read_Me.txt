Buttfaces Digital Type Foundry
Greetings Font Fans!
Okay, It all started back about 20 years ago. I was about ten years old and I know you won't believe this, but I was in a bathroom. I had a little time on my hands so I started to look around. As I noticed my mother's various cosmetic products, I began to feel that certain ones were better than others, just by the look of their labels. I didn't know why I felt this way at the time, but I later learned that it was the design and typography of the labels that convinced me of their value. Well, I eventually doodled on enough math class notebooks to get myself into a graphic design career. Letters have always fascinated me, so I set down to create a few faces. Remembering my inspiration, and that most great discoveries take place in the bathroom, I dubbed them "Buttfaces". Hope you like 'em and remember: Don't take any crap...
This font is in Truetype format. To use it please install using the appropriate software(i.e. Windows control panel, Windows95 control panel, etc).
Below is a description of the fonts I currently have available on-line.

SKUTTLEBUTT: Skuttlebutt Family  $10.00 (US); Light, Medium, Bold and Extra. 
Everybody's talking about it. Check out the latest skuttlebutt. This is a funky hand lettered font that includes a complete international character set.

CHUNKYBUTT: Chunkybutt family $10.00 (US); Regular and Supa-Chunkybutt. We all have secretly admired them from afar, now own one for yourself! A fun font that appears to shake at smaller point sizes. Since it's the first officially finished Buttfaces� font, you get both Chunkybutt and Supa-Chunkybutt for only $10!

BUTTWRITER: $10.00 (US) I almost scrapped this one, but two friends picked it as their favorite. Funny how that sort of thing works. I like the fact that what one person creates and evaluates as "okay", another says "WOW". Gives you some faith, doesn't it? A degraded half-toned typewriter font. Looks like bad typewriter type at small sizes and gets much cooler when set big.

BUTTSKERVILLE: $10.00 (US) A fun take on a typography classic! This is a scribbly font that includes a complete international character set.

PUNK-ASS: Punk-Ass family $10.00 (US); Big and Little. Here's some major grunge for all you snot-nosed punks in yer twenties - Okay, I just turned 30 and yes, I am bitter! Seriously, a font that's been beaten and shredded. Best at large point sizes.

ENEMA: Enema Family $10.00 (US; Regular, Bold and Superlight. (Light is Free) This ones been through some serious crap. I was shooting for that bad copier/rubber stamp look.

BUTTHEADS: $10.00 (US) Finally revenge on all those Buttheads in my life. 30+ Caricatures of some very unique people. (you know who you are.)

BUTTKOWSKI: Buttkowski Family $10.00 (US); Light, Medium and Bold. An outline serif with a slightly rough feel. Great at large sizes or for text weights. Includes a complete international character set.

CURLIEBUTT: Curliebutt Family $10.00 (US); Normal, Bold and Black. Curlie, Funkie, Goofie, Sillie. Inspired by our favorite cartoons! An all caps font that has an uppercase with curlie serifs, and the lowercase without. Several characters have extra variants.

HEADBUTT: Headbutt Family $10.00 (US); Regular and Bold. A painful whack in the head is good for you every so often! Or think of it as what you see on Sunday Morning after a crazy Saturday night. This Half toney outline font includes a complete international character set..

CIGGIEBUTT: $10.00 (US) Smokers welcome here! Use this font to evoke that distressed feel and smoke your competition! (Woo, that was a bad one.) This font looks like the edges are burned away.

THE WHOLE BUTT-LOAD: $35.00 (US) This is our BEST DEAL. It includes all of the above fonts. Over 65% off of the individual price of the fonts!

DISTRIBUTION You have permission to pass the trial versions of these fonts on to your friends for evaluation as long as all files (including the order form and this readme file) are included. The fonts are copyrighted software so if you wish to include them with any font collection for sale (on disk or CD ROM etc.) you must contact me and receive written permission. These font files may not be posted on any web page, newsgroup, or other online service without my specific permission cause Font Pirates are real Buttheads. You are welcome to create a link to the Buttfaces website.

How do I get the full version?These fonts are "trial version" provided so that you can get a feel for the fonts before buying them. If you would like to order the full version just fill in the order form text file also included with this file. Send check, money order or cash payable to Tobias Tylus to the address below. Don't forget to include shipping and handling. ($3.00 US OR $5.00 Foreign) or your e-mail address to receive them online.

When you register I will send you info on all of the other Buttfaces Fonts that I have created and how to get them!

Visit Our Web Site At: http://www.buttfaces.com

Thank you very much, and I hope that you design some cool stuff with these fonts - that's why I made them. I'd also love to see what you've done with them. Please feel free to e-mail or snail mail me print samples or web site url's that you've used them on. I'll include them on a future "sightings" page on the site and link back to you.

Tobias Tylus
Buttfaces Digital Type Foundry
PO Box 700304
Dallas, TX  75370
Email: Tobiast@buttfaces.com
http://www.buttfaces.com
All this stuff copyright Tobias Tylus and Buttfaces 1997.
