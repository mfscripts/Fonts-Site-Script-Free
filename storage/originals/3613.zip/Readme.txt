===========================================================================
            Welcome to Mark Zanzig's Fun Font Pack Volume 1
===========================================================================

The fonts of Mark Zanzig�s Fun Font Pack 1 are copyright protected. But
since the collection is distributed in the spirit of shareware, you may
give them to your friends and co-workers or upload it to your preferred
Bulletin Board System (BBS), provided you transfer all files unchanged,
including this file (README.TXT) and the documentation in Adobe Acrobat
format (MZFF1.PDF). If you don't have the reader yet, you might want to
download it from CompuServe (GO ACROBAT) or Adobe's World-Wide-Web-Server
(WWW.ADOBE.COM).

Anyway, if you decide to keep one or more fonts of the collection on your
system to use it for your layouts and design projects (i.e. to earn money
with it), you are required to pay for the fonts!

To register send $25 cash (German residents please send a cheque of
DM 35,00) for the complete Pack of nine fonts to the following adress:

Mark Zanzig
Muehlenstrasse 53 d
D-25421 Pinneberg
Germany

Members of CompuServe Information Services (CIS) might want to register
through the shareware registration section: Simply GO SWREG and watch out
for CIS-UID 100541,3641.

If you register you�ll be shipped a single 3,5" disk containing the latest
versions of the fonts in both TrueType- and Adobe Type-1-format, and even
more: You�ll get Mark Zanzig�s Fun Font Pack 2 for evaluation as soon as
it is available.

If you encounter any problems installing and/or using the fonts, please do
one of the follwoing (and indicate clearly the trouble you have, including
system platform, operating system, processor and so on):

(1) write to the adress mentioned above
(2) E-Mail me under 100541.3641@compuserve.com
(3) send a fax to +49 41 01 51 49 09.

Thank you for evaluating this font collection!