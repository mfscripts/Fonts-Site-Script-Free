Red Circle computer font �2000 Harold Lohner

FREEWARE-Distribute freely.

Based on the lettering formerly used on Eight O'Clock brand coffees.

HLohner@aol.com
http://members.aol.com/fontner
