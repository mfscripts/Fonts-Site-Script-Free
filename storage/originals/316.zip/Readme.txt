Kiwi Media presents...

ERASURE

In the continuing tradition of pumping out fonts that are based on album 
covers...

"Erasure" is based on the all-small sans-serif font used on the cover of 
the Erasure albums "Chorus", "Abba-esque" and any subsequent singles.  All 
standard characters are included, the small letters having fractional 
widths and some specially-designed characters for the "connected" pairs 
(re, ur, etc.)  I was going to just do this with kerning pairs, but I 
noticed that there's a bit more to the original type than that.  So I did 
a lot of tinkering in Canvas and Fontographer and the result is pretty 
close.  A few dingbats, like the Erasure "e" logo and the Mute records 
logo are mapped to the "~" key.  The full "erasure" logo is somewhere on 
the "\" key.

So now I'm sure you're asking "what do you want out of all of this?"  The 
answer is, naturally, money, fame and power.   $5 would be nice, but if 
you've got any fame and power you'd like to give me I'll take that too.   
The address for all this is:

Eric Oehler
wonkor@yar.cs.wisc.edu

I move a lot, so the best way to contact me would be to email me.

Legalese:  erasure is a font copyright 1993 Eric Oehler for the Kiwi Media 
group.  This font may be distributed freely as long as this notice is 
attatched.  Kiwi Media is in no way related to Kiwi Software (in fact Kiwi 
Media predates them by about 3 years but I'm not going to make a stink 
about it).

There're a lot more fonts out there that I've done.  You can see them all 
on the web at http://yar.cs.wisc.edu/cold/graphics/wonkofonts.html.

Enjoy.

Eric Oehler
Current and Only Head Cheese for Kiwi Media.  
 