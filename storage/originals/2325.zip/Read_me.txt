Etherbrian

---> etherbrian@aol.com
          http://members.aol.com/etherbrian <---

This font is in TrueType format. To use it, simply drag it to your System folder. You'll be asked whether you want to save it in your Fonts folder; be brave and do it. Applications that you have open cannot utilize the font until after you have quit them and re-opended them; get cracking.

Bear in mind that since this font is free, the time and energy that goes into creating commercial-quality fonts has definitely not been utilized. I'm not saying that the font is bad ... I actually like a few of these ... but it's best that whatever type you've set should be converted to outlines and kerned by hand. Folks with a keen attention to detail and pride in their work do that anyway, don't they? And tell your friends: this font is AS IS, NO WARRANTY, and furthermore AT YOUR OWN RISK. Type nice words!

Have a nice day ---> Brian            