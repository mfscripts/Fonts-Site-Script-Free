"Doodle" is a shareware font.
If you want to use it for individual purposes, the cost is $5.
If you want to use it commercially, the cost is $25.
The integrity of the shareware concept depends upon the honor system.
Even though I would probably never know if you used the font without
paying for it, I would hope you fear God.  Please send payments to:	

			Gene M. Grubb
			509 Monterey
			Danville, IL 61832

Check it first to make sure it works, then send the money.
No technical support will be available.
     
You are free to distribute the ZIP file in its entirety,
but you may not distribute the font file without this ReadMe file.

The characters are upper case only.
A second version of the "D," "E," and "O' characters are available
by striking their lower case keys.