AntiMatter font
Release date: 31 January 1999, London, UK

AniMatter is Thankware! When downloading it from HYBRIDspace, all i ask you is to drop me a message (xino@luna.nl) to thank me. If you use it on a website, i'd appreciate it if you'd include a link to this site. If you use it for commercial print, i'd appreciate it if you would somewhere mention my name, the font name, or HYBRIDspace. Thank *you*! 

You may use AntiMatter without payment, but you may not sell this font or distribute any modified version without my written
permission. AntiMatter may not be distributed without this text file.

"Free font" websites must include a link to HYBRIDspace <http://home.luna.nl/~xino> if AntiMatter is made available for download.


Have luck & make fun!

Kees Gajentaan


More fonts i've designed can be downloaded from
HYBRIDspace: http://home.luna.nl/~xino

E-mail: xino@luna.nl

AntiMatter font (c) 1999 Kees Gajentaan. All rights reserved.


