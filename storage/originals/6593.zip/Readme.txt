******* GRAFOMAN FONT ************************
**********************************************
Copyright (c) Denis A Serikov. 2001.
Freeware version.

**********************************************
** TYPE: True Type/ Type 1 Font **************

** Dos Name: GRAFMAN_ (ttf) GRAF____ (type1) *

** KERNING: NO KERNING ***********************
**********************************************

************* The KIT ************************

True Type Font.         53kb
Type1 Font.             36kb
Readme File.  (txt).   912bt
Fontface File (pdf).    28kb

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Feel free to share this font with others,
but please include this documentation.

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

 Denis A Serikov. All rights Reserved! 2001.
 E - Mail: denis_box@mtu-net.ru.
**********************************************

P.S. *** Thank you! *** 