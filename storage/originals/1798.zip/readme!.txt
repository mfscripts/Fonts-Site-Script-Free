� Copyright �
Altenburg v. 1.0 - Copyright 1996, David F. Nalle - Scriptorium Font Library.  To register this font and get a disk of fonts send $15 to Ragnarok, POB 140333, Austin, TX 78714.
