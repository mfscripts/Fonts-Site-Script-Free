Hullo! You have just downloaded a font created by Alan Bauchop. He worked hard. Assuming that you're using it in a commercial capacity, he would like some remuneration. A paltry US$10 please. Send to:

Alan Bauchop
63 Alexandra Rd
Mt. Victoria
Wellington 
New Zealand

Cheers! If its just personal use that you'll be using the font for its freeware! Enjoy! You can always feel free to send Alan a wee e-mail for the sake of feedback: 

alan@splashmedia.co.nz

If you downloaded this font from anywhere other than 'Sophtecks' be sure to check out the site for the latest font releases:

http://www.splashmedia.co.nz/users/sophtecks/

Distribute the font freely, either personally or over the net, but please do not seperate the read_me file from the font, lest they get lonely! Disclaimer: If your computer dies as a result of anything to do with this font, Alan cannot be held responsible. See-Ya!