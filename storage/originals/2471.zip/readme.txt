This font is freeware for private and commercial use as long as you do not make profit with the font itself!
Its is NOT allowed to sell this font!!

I made this font for Claudia from "B�ro-Design" http://www.luxa.de/buero-design/
to give a liitle bit back for all she has dne for me.

If you want to show it on a shareware CD please contact me by email (dieter@fontmaker.de)
The font can be used for everything you want just enjoy it and have fun.

You can put this font in an online archive.
If you offer more then 5 fonts of me in an archive i require a link to my web site!

That's all - isnt it simple? ;-)

For more free fonts like this visit my web site:
www.fontmaker.de - Fontmaker - free fonts for free people!

Have fun with fonts
Dieter Schumacher