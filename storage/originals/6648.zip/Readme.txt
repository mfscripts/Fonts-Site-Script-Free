--------------------------------------------------------
If you using Windows Notepad, please make sure to set 
your left and right margins to zero before printing.
--------------------------------------------------------

-------------The "Notice" font -------------------------
--------------------------------------------------------
Copyright (c) Denis A Serikov. 2002.
Full version.

--------------------------------------------------------
--- Font Type: True Type / Type 1 Font -----------------

--- Dos Name: NOTICE__ (ttf) NO______ (type1) ----------

--- KERNING: No Kerning --------------------------------
--------------------------------------------------------

--------------------- The KIT --------------------------

True Type Font.            52kb
Type1 Font.                34kb
Readme File.  (txt).        1kb
Fontface File (pdf).       17kb

________________________________________________________

This font is free for non-commercial uses.  
Please e-mail the author at:
        denis_box@mtu-net.ru
________________________________________________________

--------------------------------------------------------
Denis A Serikov.
Russia. Moskow.
All rights Reserved! 2002.
E-Mail: denis_box@mtu-net.ru.

--------------------------------------------------------
--------------------------------------------------------
P.S. ---------------- Thank you! -----------------------



