       Thai (Siamese) look-alike font with English (Latin) characters:
                         "AW_Siam English not Thai"

                                  
Download the font for Windows from http://www.weygandt.de/aw_siam.zip (a
TrueType and a PostScript Type 1 font)
Mac: http://www.weygandt.de/aw_siam.bin

WHY?

I saw a sign in the movie street fighter (van Damme) that looked like
written with a typical Thai font but when I had a closer look, the signs
were written in English (Latin) characters. No one had it so I made it. And
this is it. I guess I'd have to class this as an unfinished version as some
characters should have a lot more attention but for now I was more
interested in some of the other stuff.

Thanks to Jos Flachs in Bangkok for his expert suggestions. Without him,
the font would be half as good.

Enjoy!

Andreas Weygandt

  ------------------------------------------------------------------------

INSTALLATION

   * To install, simply copy the "aw_siam.ttf" file to the windows fonts
     folder (normally C:\WINDOWS\FONTS). Make sure that the kerning is on -
     in MS Word default is off.
     Postscript Font: When you use postscript fonts you know how to install
     them.
     Mac: I don't know.
   * To remove simply delete the "aw_siam.ttf" file from the fonts folder,
     but why you want to do this is beyond my comprehension.



UNKNOWN PROBLEMS

Tell me and I'll try and fix it!



RELEASE NOTES

   * V 0.1  I made it! The ugly raw version (one evening's work)
   * V 0.1a All letters the same height, some letters replaced, tweaked
   * V 0.1b Some letters replaced, tweaked, German Umlaute
   * V 0.1c Letters replaced
   * V 0.21 Fine tuning, spacing, kerning, letters replaced
   * V 0.30 Real small caps (still ugly, better use the upper caps)
   * V 0.31 Minor changes

TO DO:

   * Numbers
   * Fine tuning
   * Tell me!

TECHNICAL STUFF

   * Characters borrowed, twisted and tweaked from the DB ThaiText font
   * Em square 1000
   * Ascent 800
   * Descent 200
   * Line width 100
   * Small letters size 70 % -> weight +35 em units

  ------------------------------------------------------------------------

  No copyright infringement is intended. This font is FREE and may not be
         used for profit. If you like and use it, send me an email:
                            Andreas@Weygandt.de
  This font is provided as is. The author takes no responsibility for any
 damage that is done to your system thru it's use. It works fine for me! If
                  it doesn't for you, it ain't my fault!

   Sounds impressive doesn't it? Well it was! (Hey I was impressed at the
                                   time)

                                 10. Jun 00

  ------------------------------------------------------------------------
