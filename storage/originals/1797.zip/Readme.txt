                THE OLD ENGLISH FONT PACK FOR WINDOWS

                          by Peter S. Baker
                       peterbaker@virginia.edu

For detailed instructions on the use of these fonts, see the enclosed
document oeps.rtf. This is a Rich Text Format document and may be viewed
and printed from any word processor that supports that format.
