Strange World font by Chris Hansen

i was originally gonna call it Sad World, but it did't look that good, so i wen't after Kyle's line in Blue Velvet

Contact

Crizcrack_666@hotmail.com	

www.geocities.com/crizcrack666