--------------------------------------------------------
If you using Windows Notepad, please make sure to set 
your left and right margins to zero before printing.
--------------------------------------------------------

-------------- Clip Condensed --------------------------
--------------------------------------------------------
Copyright (c) Denis A Serikov. 03.03.2002 21:15

--------------------------------------------------------
--- Font Type: True Type / Type 1 Font -----------------

--- Dos Name: CLIPCD__ (ttf) CLCD____ (type1) ----------

--- KERNING: 1619 Pairs --------------------------------
--------------------------------------------------------

--------------------- The KIT --------------------------

True Type Font.            47 kb
Type1 Font.                72 kb
Readme File.  (txt).      1,4 kb
Fontface File (pdf).       25 kb

________________________________________________________

This font is free for non-commercial uses.  
Please e-mail the author at:
        denis_box@mtu-net.ru
________________________________________________________

--------------------------------------------------------
Denis A Serikov.
Russia. Moscow.
All rights Reserved! 03.03.2002.
E-Mail: denis_box@mtu-net.ru.

--------------------------------------------------------
--------------------------------------------------------
P.S. ---------------- Thank you! -----------------------



