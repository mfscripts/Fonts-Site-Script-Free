------------------------------------------------------------------
Morgus the Magnificent:
A font based on the horror host Morgus,

------------------------------------------------------------------

------------------------------------------------------------------
1. These fonts are completely free, you can use them in any
way you see fit. email me if you use them for something useful.
2. Please keep this archive intact along with this readme file.
3. And if you want to put these onto a magazine floppy, CD-Rom,
go ahead, as long as you follow (2).
-----------------------------------------------------------------
Dreadful Productions
p.o. box 584
royal oak, michigan
48068-0584
email: dreadfulproductions@mail.com
