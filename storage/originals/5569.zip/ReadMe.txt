Hi...this is a font that I made modeled after the Cure's Head on the Door album. To install it: In Windows 95: put into c:\windows\fonts. On the Mac, drop into your system folder. In Windoze 3.x, you're on you rown...I can't remember! If you really want to know, e-mail me and I'll figure it out somehow!

This font is SHAREWARE! That means that if you use it and you like it you should
 pay for it. Please! I spent countless hours and who knows how much irreversible
 wrist damage working on this font...Support shareware and pay! Please don't use this font on web pages, art, or anything else without registering it!

If you don't want to pay me but would other wise like to show your *undying gratitude*, e-mail me and we can work out a deal...perhaps some nifty Cure bootlegs or something... =)

I am only asking $5....I think that's more than reasonable, don't you?

Please send to:

Jennifer Dickert
20 Spring St.
Apt. B-2
Norwalk, CT
06854
USA

smooshie@juno.com
-or-
mintcure@geocities.com

http://www.geocities.com/SunsetStrip/Palms/1552

This font could not have been possible if not fot the sheer elegance, stability and ease of use of the Macintosh OS....

Hey Windoze users: does this sound familiar?

Bad Windoze!!!
Roll over! 
Uhhhh....play dead? 
Goooooood Windoze! 
How would you like mommy to give you a nice cold reboot? 
Then will you behave for mommy?

I think you get the idea...

The Cure, Head on the Door and it's artwork are all copyright the Cure, Parched Art, Fiction Records, Electra Records and anyone else affiliated with the Cure and this album. Please don't sue me! I am just a lowly college student who does this as a lobor of love!