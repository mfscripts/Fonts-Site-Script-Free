Thank you for downloading fonts from ABSTRACT FONTS!

This font is SHAREWARE, that means that you can try it, but if you want to use it please send me $5 for personal use and $20 for use in software program. Please support us...

You cannot derive, rename or distribute this font on any commercial CD or floppy and you cannot sell them.

To argue contact us: alex@abstractfonts.com
 
If you'd like to make a donation we'd be more than happy to accept it to cover our web site's hosting fees.

No donation is too small!

Send anything at all to

Alexandr Chumak
1701 Wavell Cres., apt#202
Mississauga
Ontario, CANADA
L4X 1X2

If you decide to send a cheque please make it payable to Alexandr Chumak.

Canadian or US funds?  Any funds are fine with me.
Whatever's easy for you.

Alex Chumak,
alex@abstractfonts.com
fedesigns@netscape.net
alchum@idirect.com
http://www.abstractfonts.com