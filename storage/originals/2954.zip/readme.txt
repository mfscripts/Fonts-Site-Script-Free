�1997 Oliver Conte Design. All rights reserved. 
This font is intended as freeware and may be copied and distributed freely. 
http://www.ocdesign.com/goodies.htm

You can reach Oliver Conte Design via email as well:

info@ocdesign.com