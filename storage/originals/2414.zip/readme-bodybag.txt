     _  _ ____ _    _    ____    ___ _  _ ____ ____ ____
     |__| |___ |    |    |  |     |  |__| |___ |__/ |___
     |  | |___ |___ |___ |__|     |  |  | |___ |  \ |___

 -------� M R . F I S K  I N V E R S I O N S  I N C.-----------

 Here is a new one, not quite like a fucked or cracked font but
 deadly like anyway I think  B O D Y  B A G �

 **************************************************************

 Can you write me when u have installed it into your computor :
 ----------------> fuck.the.world@mail.ru <--------------------

 **************************************************************
 ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    ##     ## ########      ######## ####  ######  ##    ##
    ###   ### ##     ##     ##        ##  ##    ## ##   ##
    #### #### ##     ##     ##        ##  ##       ##  ##
    ## ### ## ########      ######    ##   ######  #####
    ##     ## ##   ##       ##        ##        ## ##  ##
    ##     ## ##    ##  ### ##        ##  ##    ## ##   ##
    ##     ## ##     ## ### ##       ####  ######  ##    ## TM

               |||||||  ||||||| ||||   || ||||||||
               ||       ||   || || ||  ||    ||
               ||||||   ||   || ||  || ||    ||
               ||       ||   || ||   ||||    ||
               ||       ||||||| ||    |||    ||

               ||    || ||||||| ||      |||||||
               ||    || ||   || ||      || 
               |||||||| ||   || ||      |||||||
               ||    || ||   || ||      ||
               ||    || ||||||| ||||||| ||||||| TM
 ................................................................
 -------------------------ICQ : 10131645-------------------------

 MR.FISK OFFICIAL FONT-HOLE  <> http://www.fiskish.net/fonts.shtml
 MR.FISK UNOFFICIAL FONT-HOLE <> http://hem2.passagen.se/akkustic/

 ----------------------------------------------------------------
                        .. do you love me ? ..
 |---------------------------------------------------------------|
 |                                                               |
 |   Info Board:   font-problems 'n stuff                        |
 |                                                               |
 |   I use ScanFont when I create my fonts. If the fonts look    |
 |   bad or if the malfunction or if youre a fan, just write me :|                 |
 |   fuck-the-world@mail.ru                                      |
 |   Any other problems : read the help file.                    |
 |                                                               |
 |---------------------------------------------------------------|
     N E W S F L A S H : S O O N  T O  B E  R E L E A S E D :
 A  M R  .  F I S K  - T  S H I R T  f o r  $ 1 0  i n c l.  p & p
   [ p u r e  h a n d  m a d e  o n l y  1 0 0  c o p i e s ]
------------------------------------------------------------------
..........................T a k e  C a r e........................