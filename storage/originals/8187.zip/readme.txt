This font is a shareware release from Arrgghhh! Graphics and the SludgePuppy Type Foundry. Like our other fonts it contains upper and lower case letter, numbers, punctuation, fractions and Bullets/Dingbats. The fractions were added to make things easier and the symbols were added to make things more interesting. This font was created using Corel Draw and Fontographer 3.5 for Windows. It is offered as shareware by The SlushPuppy Type Foundry. The fee for this shareware font is $4. This will encourage the making of more fonts.

For 30 days and/or after paying the shareware fee this font is yours to use. You will have unlimited rights to use this font in any form except to make another font file. You may not convert the font to another format and re-distribute it.

Copies of the complete archived file, as you received it, may be posted on bulletin boards as long as you include this text file. You are encouraged to do so with my blessing and thanks.

Mail payments (and comments, grips and accolades) to:

Jonathan Smith
11330 Hessler Rd.
Cleveland, Ohio 44106

Comments?
For fastest response I can be reached through the Internet at:
an053@cleveland.freenet.edu

Or at:
Jonathan55@aol.com

Fonts from SludgePuppy  may be included on collections of Public Domain and Shareware disks. Please contact the above address about distribution or other fonts. If you paid for a disk with any of these fonts you are still required to send in your registration fee if you decide to keep them. In other words:  We will continue to release fonts in a non-crippled format as long as there is a fair response to the registration fee.

Thanks for trying this font, please look for other fonts from SP Foundry, including a set of unusual Dingbats soon to be released.

Notes: To install .TTF files, use the Windows Control Panel (Fonts/Add).

