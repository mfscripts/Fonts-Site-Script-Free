 ___   __  _  _  ____  __  __  ___  ___   __      __  __  __  __ 
(  _) /  \( \( )(_  _)(  \/  )(  _)/ __) (  )    / _)/  \(  \/  )
 ) _)( () ))  (   )(   )    (  ) _)\__ \ /__\  _( (_( () ))    ( 
(_)   \__/(_)\_) (__) (_/\/\_)(___)(___/(_)(_)(_)\__)\__/(_/\/\_)

	Font Name - Mighty Rapids v1.0 (Freeware)
*******************************************************


	Available for PC Truetype and Type1
	International Characters: Yes
	Euro symbol: Yes
	Kerning: Yes
	Platform: Win95, Win98, WinME
*******************************************************

	Mighty Rapids is a font based on the Mercury Marine Outboard Motor Co. Logo
	http://www.mercurymarine.com

	Two sets of numbers have been included in the set, one with waves and a standard
	set without waves. The numbers with waves are on the regular number keys and the 
	numbers without waves set can be accessed by holding down the shift key and pressing
	any of the regular number keys.
	


	
      
      
      
  