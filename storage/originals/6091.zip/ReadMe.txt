RUTHERFORD
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

There isn't much of a tale to tell with Rutherford, the font, although Rutherford, the Halfling is another matter (for another time). I named this font after Dan Jasman's old character in my fantasy game because this font seems to have the same kind of casual, goofy friendliness about it. I drew it, appropriately enough, while gaming a few weeks ago, so it's properly embued with the spirit of fellowship, and in light of recent cinema releases, fellowship, halflings and the rest all seem to come together nicely.

Version 1.0

This font is copyright 2001 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for personal, non-commercial use of any kind (including website decoration and so on). Contact me at sjohn@io.com if you're interested in a commercial license; rates will depend on the details.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.