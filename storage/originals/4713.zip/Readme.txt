13th Degree Font Foundry
All Files included are Copyright 1999 Zane Townsend.

Web Site:  http://members.xoom.com/13th_degree/
Email:    ztownsend@hotmail.com
______________________________________________________________________________

Revision notes:  None, 1st release.

Special character notes:  None.

Other Notes: This is the first font I ever made, it took the longest to make
and was the hardest to do, I learned alot though.

______________________________________________________________________________

This font package is Shareware. If you wish to distribute it,
please include all of files that came with along with this document
(consisting of; license.txt, license.htm, Readme.txt, file_id.diz, 13th_degree.url,
and all other files included with the original.)  

If you would like to be added to my mailing list, please send me an email
with "Update" as the subject.