illegal industriez fonts info

Nederlands
Deze lettertypes zijn eigendom van illegal industriez design.
Zij mogen vrij gebruikt of gecopieerd worden, wanneer
er dit tekstbestand bij geleverd. Suggesties of reacties?
Aarzel niet, bel of mail ons!

~

English
These fonts are still owned by illegal industriez design.
You can use or copy them, but only when this textfile is included
in the font-folder. Suggestions or reactions?
Don't hesitate, call or mail us!

_____________________________________________________

illegal industriez design
studio for new media, typography, audiovisual and graphic design

T  +31 [0]10 478 17 59  
M  +31 [0]6 52 95 15 74
@  illegal@euronet.nl

Visit the illegal_world at: www.euronet.nl/users/illegal/

_____________________________________________________

�1998, illegal industriez Rotterdam, Holland
