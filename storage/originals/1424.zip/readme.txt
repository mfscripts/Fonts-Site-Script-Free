\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
*********************************************************************************
m	g	m	/	d	e	s	i	g	n	s
*********************************************************************************
/////////////////////////////////////////////////////////////////////////////////

Hey!

Hardcore was created on the 6th of May, 1997 & it is _ofcourse_ freeware.
This is the second version of it and it contains better kerning of stuff like that.
If you would like to send a small contribution to a hard-working teen student,
you can do so to the following address:
				___________________
				|   mgm/designs   |
				|c/o Mattia Marchi|
				|  S-13148 Nacka  |
				|      Sweden     |
				�������������������

Thanks a bunch!!!

The ZIP-archive should be called: MGM-HC.ZIP
and it SHOULD contain the following files:
- README.TXT [THE FILE YOU'RE READING NOW]
- HC___.TTF [PC TRUETYPE FONT]

-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-
-----------------------------------mgm/designs-----------------------------------
-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-'-
		       homepage - http://mgmdesigns.home.ml.org
			     email - hmm@hem.passagen.se
				    icq - 1281557

