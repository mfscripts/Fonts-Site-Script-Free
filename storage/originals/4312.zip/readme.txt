fuelfonts shareware fonts readme.
All Fonts Copyright � 1997 Claes K�llarsson / fuelfonts.
http://www.fuelfonts.com

If you like my shareware fonts,
please send 10 US dollars to:

fuelfonts
c/o Claes K�llarsson
Skimmelv. 7
857 52 Sundsvall
Sweden

important information!
Here are some information i want you to read and
understand. These rules are not for annoying you,
just so that you know what i want from you.

Do NOT redistribute these fonts, if you want to
redistribute my fonts first email me at:
grizzly@fucker.com and ask me. I don't like to
find out myself that someone is distributing my
fonts without telling me first. second of all,
include this readme file, the order file and the
original, unchanged truetype file.

Do NOT remake these fonts, dont open it in
Fontographer or any other fontprogram to remake
it, if you have an idea for one of my fonts and
wishes to remix it for me, email me at:
grizzly@fucker.com and tell me. if i like the idea
i might let you remake it and i will distribute
it from my site, crediting you for the work.

These fonts are copyrighted under law.
Breaking these laws might lead to legal problems
for you and me, which we both do not want.

Copyright � 1997 Claes K�llarsson.
All Rights Reserved.