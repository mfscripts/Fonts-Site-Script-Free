Congratulations!  You've gotten your hands on a great dingbat font
provided by Dingbat Crazy.  Whether it's freeware or shareware, one
thing you can rely on is findability. We work hard to find all the
dingbats on the net and make them available to you.

Please be sure to read the author's info file (if there is one),
and take the appropriate steps as per their instructions.  Some
authors even though offering a font for free, require a link back
to their site, others just want to see what you've made with it,
and yet others may require you to register your free font.  
Whatever the case, it is up to you to fulfill their requirements.

Dingbat Crazy makes no assumptions and gives no assurances as to
the usability of any font downloaded from our site.  We do not
make the fonts and make no guarrantees thereof.

If you've downloaded an Ozmee font, however, please feel free to
contact me if you have any problems or questions pertaining to it.
All free Ozmee fonts may be used in any fashion you so desire.  A
fee is no longer required for any Ozmee font unless specifically
stated as a shareware font.

Come back again for more great dingbat fonts and keep your eyes
open for an updated, improved collection of dingfonts coming soon!

Dingbat Crazy
http://members.xoom.com/fontsrus/index.htm
ozmee@hotmail.com