This free font was created by Michelle Potier for
http://www.vacuity.de