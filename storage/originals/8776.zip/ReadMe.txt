THUNDER THIGHS
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

Thunder Thighs is a goofy, friendly sort of font, reminiscent of cartoon logos and the like from the late 1970s. Those kinds of shapes, and the comforting nature of huge amounts of black ink on formerly-blank paper, made this one a particularly enjoyable one to create. I drew it with a 0.8mm Pigma and then blackened it with my trusty Sharpie; the whole process was a kind of reversion to childhood. Same principle as "comfort food," I suppose - a valuable concept in these troubled times.

Thunder Thighs is a full keyboard set with a few essential extras like smartquotes and dashes.

Version 1.0

This font is copyright 2001 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for personal, non-commercial use of any kind (including website decoration and so on). Contact me at sjohn@io.com if you're interested in a commercial license; rates will depend on the details.

This archive may be freely distributed provided none of the contents are altered or removed.