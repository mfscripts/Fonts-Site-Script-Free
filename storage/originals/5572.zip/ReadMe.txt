Hi...this is a font that I made modeled after the Cure's The Walk EP. To install it: In Windows 95: put into c:\windows\fonts. On the Mac, drop into your system folder. In Windoze 3.x, go to the Control Panel and then double click on Fonts. Then click on Add New Font and point it to where the new font is. Please keep in mind that it has been a *really* long time since I have used Win 3.11 and I am typing this out of memory, but this should give you a general idea of how to do it.

This font is SHAREWARE! That means that if you use it and you like it you should
 pay for it. Please! I spent countless hours and who knows how much irreversible
 wrist damage working on this font...Support shareware and pay! Please don't use this font on web pages, art, or anything else without registering it!

If you don't want to pay me but would other wise like to show your *undying gratitude*, e-mail me and we can work out a deal...perhaps some nifty Cure bootlegs or something... =)

I am only asking $5....I think that's more than reasonable, don't you?

Please send to:

Jennifer Dickert
20 Spring St.
Apt. B-2
Norwalk, CT
06854
USA

smooshie@juno.com
-or-
mintcure@geocities.com

http://www.geocities.com/SunsetStrip/Palms/1552

This font could not have been possible if not fot the sheer elegance, stability and ease of use of the Macintosh OS....

Hey Windoze users: does this sound familiar?

Bad Windoze!!!
Roll over! 
Uhhhh....play dead? 
Goooooood Windoze! 
How would you like mommy to give you a nice cold reboot? 
Then will you behave for mommy?

I think you get the idea...

The Cure, The Walk and it's artwork are all copyright the Cure, Parched Art, Fiction Records, Electra Records and anyone else affiliated with the Cure and this album. Please don't sue me! I am just a lowly college student who does this as a lobor of love!