
   ---- File information -----------
     File:  Back.ttf
     Date:  1 Mar 2001, 15:01
     Size:  16548 bytes.
     Type:  Unknown
--------------------------------------------------------------------------------DOCUMENTATION FOR BACK TO THE FUTURE TRUE TYPE FONT

� 2000-01 Richard Walledge <Richard.Walledge@stud.umist.ac.uk>
If this version is more than 6 months old, get the newest version from:
www.geocities.com/kesmaster.geo

Software available from www.high-logic.com
Based on and inspired by the font "DoubleBack"


CONDITIONS OF USE
1	You can use and distribute this font for free. I created it as a 
	hobby and out of the goodness of my heart, and all I ask is that 
	you let me know what you think. Of course, if you honestly like it 
	and feel it is worth some money then I wouldn't say no to �3/$4 or 
	so per copy as a gesture of goodwill... Email me at the address 
	above if you want to make a donation.
2	Do NOT use this font to make graphics for websites. Text is text, 
	and graphics are graphics. Do not confuse the two.
	The only way to use the font on the web is to embed it. This can
	be done by converting the font into TrueDoc format, using the free
	tools at www.bitstream.com , and then using a style sheet
3	No Warranties of any kind. The font should work on both PC and Mac,
	but I stress that I am no fontographer, it's just a project!
4	Read #2 again and make sure you understand it. If you do not agree 
	to this then please delete the font.

NOTES AND ADVICE
1	Do not use mixed case words. Cases lean either left or right, so it
	just looks stupid if you capitalize the first letter of everything
2	Do not overdo it! Titles and headers are more than enough, and it 
	could get hard to read if there is too much of it
3	Font sizes much above 48pt are not recommended, as it gets blocky



VERSION HISTORY
1.0	First version, contained only upper case letters for "back" and 
	lower case letters for "future"
1.1	Added More letters so that "Back To The Future" could be written 
	in both lower and upper case
1.2	Added most other lower case letters and Capital M and I
1.3	Finished off all letters for both upper and lower case
1.4	Added numbers 1-3, and full stop and comma
1.5	Added left and right brackets, and arrows
1.6	Added special "to the" character(;) and rest of numbers
1.7	Made all characters roughly the same size
1.8	Equalized horizontal spacing and smoothed some characters
1.9	Reduced total file size by 1KB
2.0	The first completely distributable/usable version. Added lots more 
	puntuation (some "borrowed" from Arial Black)
2.1	Polished up most important letters
2.2	Improved spacing and sizing of less common characters
2.3	Smoothed more letters and numbers, and added Roman numeral I
2.4	Added a superscripted "c" as copyright character, ideal for McFly!
2.5	Smoothed even more characters, and it now looks quite good
2.6	Added characters for radiation, lightning and clockface (from Windings)
2.7	Smoothed a few more important characters (and altered time to 10:04)
		Started using new version of software
2.8	Added "part" character, and made improvements to a few letters
2.9	Improved spacing of common characters and tidied up.
3.0	Added number plate character, and trimmed file by 1KB.
3.1	Smoothed some letters and improved spacing in others.
3.2	Improved appearance of all numbers and size of some others.
