<HTML><FONT  BACK="#ffffff" style="BACKGROUND-COLOR: #ffffff" SIZE=2 PTSIZE=10>This is a freeware font...have fun with it! <BR>
<BR>
Legal mumbo jumbo: <BR>
<BR>
This font was created by me, Kat, and is FREE to use for PERSONAL USE ONLY.  It may NOT be used for commercial purposes or sold in any way.  <BR>
<BR>
My fonts MAY be placed on your website available for download, providing proper CREDIT is given to me and this README.txt file is left in tact and is included in the zip file you offer for download.  I would appreciate you asking first before you place any of my files on your site. I'd like to see where they have a new home!  Please also contact me before linking to me.<BR>
<BR>
I am not and can not be held resposible for any damages incurred to any computer after installing and/or using this font.<BR>
<BR>
All fonts have been made with freeware/royalty free images or hand drawn.  If you made any of the images or know who did, write me and I'll remove it from my site immediately upon confirmation.  No need to get all IPPITY :)<BR>
<BR>
 If you use this font, send me the link!  I'd like to see what you did with it and add your URL to my page and maybe even put in on the KR Fonts In Use page (www.katsfunfonts.com/krinuse.php3) <BR>
<BR>
You can see all of my fonts at http://www.katsfunfonts.com....<BR>
<BR>
If you like this font or have an idea for a font, let me know!  Send your mail to katsfunfonts@hotmail.com.<BR>
<BR>
Hugs<BR>
<BR>
Kat<BR>
</FONT></HTML>
