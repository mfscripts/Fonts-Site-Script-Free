jailbird.ttf

unzip to any folder, copy or send to c:\windows\fonts....

enjoy!
this font is freeware, but donations would be accepted...
if you'd rather not donate to me, then donate to someone
else in need...

comments to:

Andy Krahling
matsuan@aol.com

sunwalk fontworks
http://members.xoom.com/Krahling/page1.html
manchester, nh

custom fonts available, contact me!