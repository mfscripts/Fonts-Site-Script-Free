08 Underground
by Johan Waldenstr�m 2004

Thanks for downloading my font! This is a freeware graffiti-inspired font.
If you want to use this font commercially, please contact me by e-mail; johan@11-D.nu
I prefer a high point-size when using this font (72 points or higher).
The font only has lower case characters, so make sure capslock isn�t on when using it.
Feel free to distribute this font, or any other one of my fonts. Do not sell them though.
For the latest versions of my fonts, see www.11-D.nu

---

How to install:

Unzip the font into the fonts directory, located at c:\windows\fonts\

---

Have fun!


11-D productions

www.11-D.nu | www.uyc.nu