These two fonts contained in this archive are Freeware.
No payment is required for the use of these fonts.  They are free!
Feel free to distribute these two ttf  fonts (Xeranthemum and BlueStone) on your website, or to sent them to your friends!

But: DO NOT change the fontinfo and DO NOT rename these fonts!

Copyright: F.Kiener  Munich,Germany                            
Mail:   F@Goldgraeber.com