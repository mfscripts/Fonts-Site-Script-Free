------------------------------------------------------------------
ZERO GRAVITY v1.0, created by ShyWedge, 1999.
------------------------------------------------------------------

The following TrueType fonts are included:

 - Zero Gravity
 - Zero Gravity, Italic
 - Zero Gravity, Bold
 - Zero Gravity, Bold Italic
 - Zero Gravity Extended
 - Zero Gravity Extended, Italic
 - Zero Gravity Extended, Bold
 - Zero Gravity Extended, Bold Italic

v1.0 FEATURES
------------------------------------------------------------------

 - Includes lowercase and uppercase letters, numbers, and
   punctuation.
 - Proper spacing and kerning. 


This font package is Freeware.  If you wish to distribute it,
please include all of the above fonts along with this document
and send me an e-mail to let me know which font you have so I can
inform you of the latest updates.

Thank you for downloading this font package and enjoy!

ShyFonts by ShyWedge, 1999.
------------------------------------------------------------------
Web Site:  http://welcome.to/ShyFonts
E-mail:    ShyWedge@yahoo.com