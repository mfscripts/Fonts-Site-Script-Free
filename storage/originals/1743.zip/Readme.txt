hello! i'm eisuke.
i saw your site. so many fonts on your site made me happy!

"Believer", "Dotfont" is OK,
but I will stop free download of "Biomechanic".
because, it has regular version (this is shareware).

please upload my 2 fonts.

--
---
eisuke furukawa
for hyperion graphics
http://www.ask.or.jp/~hyperion/
