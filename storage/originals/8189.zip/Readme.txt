------------------------------------------------------------------
SF TATTLE TALES v1.0, created by ShyWedge, 1999.
------------------------------------------------------------------

The following TrueType fonts are included:

 - SF Tattle Tales
 - SF Tattle Tales, Italic
 - SF Tattle Tales, Bold
 - SF Tattle Tales, Bold Italic
 - SF Tattle Tales Condensed
 - SF Tattle Tales Condensed, Italic
 - SF Tattle Tales Condensed, Bold
 - SF Tattle Tales Condensed, Bold Italic

v1.0 FEATURES
------------------------------------------------------------------

 - Includes uppercase and lowercase letters, numbers, and limited
   punctuation.
 - Proper spacing and kerning.

SPECIAL CHARACTERS
------------------------------------------------------------------

     Tattle Tales Logo --------------------------- press *



USER AGREEMENT
------------------------------------------------------------------

This font package, SF Tattle Tales v1.0, is Freeware and may be
distributed ONLY via the Internet.  If you wish to distribute it
on your site, please include all of the above fonts along with 
this document.  For the latest updates of this and other ShyFonts
font packages, visit our site (http://welcome.to/ShyFonts).

Thank you for downloading this font package and enjoy!

ShyFonts by ShyWedge, 1999.
------------------------------------------------------------------
Web Site:  http://welcome.to/ShyFonts
E-mail:    ShyWedge@yahoo.com