
--- SWEDE-TRAUMA by MR.FISK -------------------------------------


This is freeware.
But if you wanna use it for commercial things you'll have to pay
a licensing fee. To contact me : mr.fisk @ gmail.com


Any further questions, use the emailadress.




/MR.FISK


-----------------------------------------------------------------