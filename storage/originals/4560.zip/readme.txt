Thank you for downloading "Champion" from ABSTRACT FONTS!

for the latest news, updates, legal information on the font visit:
http://www.abstractfonts.com 

This font is SHAREWARE, that means that you can try it, but if you want to use it please send me $5 for personal use and contact me if you want to use it in a commercial or public product.

You cannot derive, rename or distribute this font on any commercial CD or floppy or make it available for download that people have to pay for and you cannot sell them.

To argue contact us: alex@abstractfonts.com

Send whatever to:

Alexandr Chumak
7218 Aspen Ave.
Mississauga
Ontario, CANADA
L5N 5N8

If you decide to send a cheque please make it payable to Alexandr Chumak.

Canadian or US funds?  Any funds are fine with me. Whatever's easier for you.

Alex Chumak,
alex@abstractfonts.com
http://www.abstractfonts.com