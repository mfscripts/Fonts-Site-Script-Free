And... another font!
This is the third font released by Gemjm for free... joal and pinkPixel have had a really good success: these two fonts have been downloaded more than 700 times in less than two weeks from download.com... but we didn't get any feedback at all :P

But... this time there's an adventage if you contact us by email or in other ways: We've already designed another font, that will not be released on FTPs until April '98, but that will be distributed only via email, to the ones that will ask us for it... so PLEASE come on and write us NOW! you'll get the other cool font!

Ok... maybe we still do have to make a few corrections here... but if you want it, just email us!
That's all... after all, to design HiSky we've not passed more than  five hours behind the Mac... ;)
But it's cool enough right?

							P-ink and piXel, and all the others of the Gemjm team
       http://gemjm.home.ml.org
       email: gemjm@kagi.com