PIGEON STREET
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

Pigeon Street is ... I don't know what the hell Pigeon Street is. It's a font with most of the regular keyboard characters, uppercase, lowercase, and a fair selection of punctuation. I'll eventually expand it to include the full normal character set.

It was created from a hand-drawn sample meant to suggest a mad old woman in a medieval fantasy city somewhere, trying to come up with a fancy style of lettering for her jars of jam. That's honestly what I had in mind while drawing it - a kind of "homey" fantasy lettering font. I decided this old woman lived on Pigeon Street, because I was surrounded by pigeons at the time and it seemed the right sort of name.

That's the best explanation I can manage.

This font is copyright 2001 by S. John Ross. "Pigeon Street" and "Cumberland Games & Diversions" are trademarks of S. John Ross. This font is freeware for personal, non-commercial use of any kind (including website decoration and so on). Contact me at sjohn@io.com if you're interested in a commercial license; rates will depend on the details.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 0.9