The enclosed font(Green Dinosaur) was created by me, Christopher Gamble.  It contains only caps, and a couple of additional characters.  If you like this font, please feel free to send a small donation to:

Christopher Gamble
5333 Glenville Circle
Virginia Beach, VA  23464-5441

This is the first font I've created, and would enjoy creating more.  If you have any comments or suggestions, please feel free to email me at:

Grn_Dino@msn.com

Also, when I create more fonts they will be posted on my web site.  Please feel free to vist my site at:

http://www.angelfire.com/va/grndino
