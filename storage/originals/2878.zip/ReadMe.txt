FATTIP (font designed and created by Turntable Media)


FATTIP is free, however, we request that if you want to share it, give us proper 
credits, always include this Read Me and put a link to our page for the download.

FATTIP is Copyright � 1996 Turntable Media.

STANDARD B.S. DISCLAIMER: Turntable Media makes no warranties, either express or 
implied, regarding the fitness of FATTIP for any particular purpose. Use FATTIP 
at your own risk. The author claims no liability for data loss or any other problems 
caused directly or indirectly by FATTIP.

If you have any questions or comments send them to kids@turntable.com.

If you like the font so much that you think we deserve some money, send it to...

Turntable Media
300 Brannan Street
Suite 502
San Francisco, CA 94107
415.284.0600 tel
415.284.0685 fax
www.turntable.com
   