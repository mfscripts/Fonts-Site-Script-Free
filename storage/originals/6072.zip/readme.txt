LUNATIC
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

Lunatic is a handwriting typeface based on the more nervous and disturbing scrawlings of the font's creator, S. John Ross. It contains all the characters visible on an ordinary American keyboard, plus a couple of extras (both broken and solid vertical bar, plus the circled C and R for copyright and registered trademark, respectively). No funky
foreign characters, though (umlauts and whatnot).

Version 5.0

This font is copyright 1999 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for personal, non-commercial use of any kind (including website decoration and so on). Contact me at sjohn@io.com if you're interested in a commercial license; rates will depend on the details.