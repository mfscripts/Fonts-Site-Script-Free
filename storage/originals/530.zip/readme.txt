Catharsis Cargo
***************

A TrueType font created by Christian Thalmann (cinga at gmx dot
net).  Distribute and use freely, but not without this readme file.

Cargo is intended as a highly scalable, utilitarian font with a
certain futuristic air, especially for uses like warning signs,
spaceship hull emblems and cargo crate markings.

-- Christian Thalmann


Version history:

v1.1:  Switched to descending "a"s, so that at least the upper x
       height would be a constant for all letters.  Also no
       longer requires a different letter shape for accented 
       "a"s.  Added copyright, TM and a few other glyphs.  Made 
       the kerning a bit tighter.
       