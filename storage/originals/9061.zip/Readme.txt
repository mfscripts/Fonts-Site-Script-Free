------------------------------------------------------------------
SF MOVIE POSTER v1.2, created by ShyWedge, 1999.
------------------------------------------------------------------

The following TrueType fonts are included:

 - SF Movie Poster
 - SF Movie Poster, Italic
 - SF Movie Poster, Bold
 - SF Movie Poster, Bold Italic
 - SF Movie Poster Condensed
 - SF Movie Poster Condensed, Italic
 - SF Movie Poster Condensed, Bold
 - SF Movie Poster Condensed, Bold Italic

v1.2 UPDATES
------------------------------------------------------------------

 - Improved lettering, spacing, and kerning.


This font package is Freeware.  If you wish to distribute it,
please include all of the above fonts along with this document
and send me an e-mail to let me know which font you have so I can
inform you of the latest updates.

Thank you for downloading this font package and enjoy!

ShyFonts by ShyWedge, 1999.
------------------------------------------------------------------
Web Site:  http://welcome.to/ShyFonts
E-mail:    ShyWedge@yahoo.com