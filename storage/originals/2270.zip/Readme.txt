This font is presumed to be non-commerical,
but if you know otherwise, please send an e-mail to 
funny_fonts@yahoo.com 

http://www.torgny.net/