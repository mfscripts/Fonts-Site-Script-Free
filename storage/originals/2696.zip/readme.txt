This is an ugly font from Gregfonts!
It's distributable as long as this text file is included,
and the font is not sold for profit.
Get a new, original, free font almost every week from
Gregfonts! http://www.ktb.net/~lgm/fonts1.html

Goodbye,
Gregorioioioioioio