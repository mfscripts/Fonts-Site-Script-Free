ARCHIPELAGO
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

Archipelago is a combination between a mapping font and an alphabet font, with 26 letters and 10 number characters made up of little drawings of islands. The leters can be layered on top of one another in a drawing program to create original coastlines with a hand-drawn look. Mostly it's a novelty item, but it may be of use to some folks who want an "analog" look to a fantasy map's lines but have no access to a scanner. Plus, it can be used as a kind of "inkblot" logo font!

Hitting the SHIFT key will produce hollow (outlined) characters.

This font is copyright 2001 by S. John Ross. "Archipelago" and "Cumberland Games & Diversions" are trademarks of S. John Ross. This font is freeware for personal, non-commercial use of any kind (including website decoration and so on). Contact me at sjohn@io.com if you're interested in a commercial license; rates will depend on the details.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0