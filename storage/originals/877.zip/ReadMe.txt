
Martian Hull Markings
a Windows TrueType font
Copyright 1999 by S. John Ross
A Product of the Blue Room Fontworks
http://www.io.com/~sjohn/fonts.htm

. . . Mars needs women, and this is the alphabet they're sporting
this year on their hotrod flying saucers! Inspired by decades of
SF tradition, Martian Hull Markings is a "generic" alien alphabet.
The font is monospaced, with 26 characters total, mapped to the
normal (lowercase) alphabet, A through Z.

The font comes in two styles, "Regular" and "Gloopy" (italic). The
Regular version is inspired by the heavy lines of the old Star Trek
TV show credits. The Gloopy version is mroe organic, perhaps better
suited for alien cave-paintings or biomechanical ships.

This font is shareware. If you try it and don't like it, scrap it
or pass it on (include this file, please). If you like it and keep
it, send your registration "fee" in the form of one Complimentary
E-Mail Telling Me How You Used It, sent to sjohn@io.com

Once I recieve your e-mail, you will be a registered user, licensed
to use this font for any non-commercial purpose. Those wishing to
license this font for commercial graphic use will actually have to
pay money - email me for details.

Enjoy!

