============================
Font title: Rasstapp v. 1.0
============================

Author: Helge Carlsen (helgec@burntmail.com)


This font is freeware, so distribute 
freely, but please include this textfile!


============================
Copyright Helge Carlsen 2003
============================