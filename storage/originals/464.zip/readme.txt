Roddy
a TrueType font
by John Romero IV
nicknacknine@yahoo.com

current release:
roddy11.zip : v1.703
-includes-
Roddy (v1.703)
Roddy Bold (v1.7)

updates for v1.703
-over 300 kerning pairs
-hinting corrections to most characters

Roddy is based on the handwriting of Elizabeth Garber.







www.ivonline.co.uk
www.ivonline.co.uk/roddy