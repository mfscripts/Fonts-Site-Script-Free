ROUNDED GENIUS Font
Upper case, lower case, numerals and standard charachters

Copyright 1999 Statica Productions
Design by Jonas Stoltz

Statica Productions Font Foundry Website: http://come.to/statica
e-mail: stoltz@statica.com

This font is free to download and utilize for non-commercial purposes.  If you use this font for a commercial purpose, please contact me prior to use.  All I typically ask for is a copy of the publication for my private archive.  Not much to ask for.  

You may distribute this font consistent of the following restrictions:
1) Files contained within the rgenius.zip file cannot be modified, changed or deleted - including this text file.
2) Proper recognition to Statica Productions must be made somewhere on the hosting website - I'd appreciate a link to my website, but it is not necessary.

Thanks...




