"Syntax Error" & "Syntax Terror" Truetype Fonts
(c) 1999-2001 by ck! [Freaky Fonts]

The personal, non-commercial use of my font is free.
But Donations are accepted and highly appreciated!
The use of my fonts for commercial and profit purposes is prohibited,
unless a small donation is send to me.
Contact: ck@freakyfonts.de
These font files may not be modified or renamed.
This readme file must be included with each font, unchanged.
Redistribute? Sure, but contact me first.

If you like the font, please e-mail: 
ck@freakyfonts.de

Visit .:Freaky Fonts:. for updates and new fonts (PC & MAC) :
http://www.freakyfonts.de

Thanks to {ths} for the Mac conversion.
1@ths.nu or visit: http://www.ths.nu

Note:
"Syntax Error" : the original hardcore straight edge look,
"Syntax Terror": for all the soft-boiled sissys out there... ;)
recommended settings for "Syntax Error": 
Paintshop use: Size 8 (& multiplier) - antialising turned off
Photoshop use: Size 10 (& multiplier) - antialising turned off
All trademarks are property of their respective owners.


