Site Name: Frappe
Site URL: http://www.frappe.org
E-mail: guanabaraj@aol.com

My fonts are free to download and can be used in the following ways:

-Making graphics for your personal, nonprofit, or commercial website. If you want, e-mail me when you use one of my fonts in a graphic on your website and tell me the address of where it is being used so I can see my font in action.

-Giving them away on your website for free.  Please keep this readme file with my fonts.  A link back to my website would be nice, but it is not required.

-Making commercial items, such as tee shirts and CDs; however, I ask that you send me a copy of the product using my font if possible. If sending a product is not possible, please make an effort to tell me about the product so I'm aware. Send me an e-mail to inform me about my font being used on a product or to discuss sending me products.


My fonts cannot be used in the following ways:

-You may not sell my fonts in a font collection without my permission.  Please keep in mind that I will except something in return for the use of my fonts commercially.  Please e-mail me if you want my permission.

