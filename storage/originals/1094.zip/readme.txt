READ ME FILE FOR ASUNDER (preview edition) TRUETYPE FONT - Version 0.5p (February 1998):

This font is provided as is, Zone23 accepts no liability from its use.

This font has been released by Zone23 as Freeware for personal use and for use by non profit organisations. If you use this font on your website please send an email to zone23@webxxiii.co.uk so that we may include your site URL on our links page.

Commercial use of this font requires a license fee of �20.00 for unlimited use.

NOTE TO ALL ARCHIVERS:
Distribution of this font is strictly PROHIBITED without the written permission of Zone23. If you wish to include this font on a website or CD ROM collection you must contact Zone23 for terms and conditions. Send email to zone23@webxxiii.co.uk

Thank you for downloading our font. Please send any comments to Zone23.

Zone23
http://www.webxxiii.co.uk/zone23/