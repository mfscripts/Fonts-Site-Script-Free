fuelfonts type foundry Shareware Fonts Readme!

COPYRIGHT NOTICES
All Fonts � Claes K�llarsson /
fuelfonts type foundry. All Rights Reserved.

THESE ARE SHAREWARE FONTS !
N  O  T   F R E E W A R E !

FOR THE LATEST VERSION OF THIS README FILE, PLEASE
VISIT www.fuelfonts.com/readme/readme.txt

PERSONAL USE
These fonts are SHAREWARE, that means you can use them
for free for 30 days and after that I hope that you are
kind enough to pay the 10 US$ shareware fee if you want
to use this font more. I won't chase you with a blow
torch but if you enjoy my fonts support my work so that
I can make more shareware fonts!

COMMERCIAL USE
If you plan on using one of my shareware fonts in a
commercial project then it's not enough with just 10
us$, the fee for using one of my shareware fonts in
a commercial project is 100 US$. Contact me at my email
address (grizzly@fucker.com) if you want to use one of
my shareware fonts in a commercial project.

(commercial project = advertisements, cd-booklets,
corporate websites, movie posters, etc)

Also, the license for commercial use is for 2 CPUs
and one printer, you'll get a license file when you
pay me. the extra charge if you have to use it on
more computers/printers are 15 us$ per CPU or Printer.

If you like my shareware fonts, please send 10 us$
(or the 100 us$ commercial fee), and please send
CASH ONLY (10/100 dollar bills) because I can't
cash foreign checks. Send it to:

  fuelfonts type foundry
  c/o Claes K�llarsson
  Skimmelv�gen 7
  S-85752 Sundsvall
  S W E D E N

OTHER
REDISTRIBUTION OF THESE FONTS ARE NOT ALLOWED, THEY CANNOT
BE REDISTRIBUTED ONLINE OR ON CD-ROMS, PUBLICATIONS OR
OTHER TYPES OF MEDIA. MY FONTS ARE ONLY TO BE DOWNLOADED
FROM OUR SITE.

THESE FONTS CANNOT BE SUBLICENSED, RESOLD, LICENSED, SOLD
OR GIVEN AWAY WITH ANY MEDIA (CD-ROMS etc) WITHOUT OUR
WRITTEN APPROVAL.

hope you'll enjoy my fonts,
			     Claes

url:
 http://www.fuelfonts.com
 http://www.chank.com/fuelfonts

email:
 grizzly@fucker.com

Copyright � Claes K�llarsson / fuelfonts type foundry.
All Rights Reserved.