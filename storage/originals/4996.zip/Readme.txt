This is a shareware font made by Hilde Skj�lberg and 
Mr. Chank Diesel November 1996.
Please add this textfile if you pass on the font.

This is based on the handwriting of Hilde Skj�lberg, 
and she would love it if you sent her a mail and told 
her what you think of it.  The adress is:
                   hebe@sn.no

Thanx!