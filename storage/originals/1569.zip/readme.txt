Visit the Fontshack:  A collection of custom-made science-fiction
and fantasy fonts. 

http://members.iquest.net/~neale/resources.htm