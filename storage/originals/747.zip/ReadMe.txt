
This ZIP archive may be freely distributed, provided all three
files inside it remain intact and unaltered. For more cool stuff
like this, visit the Cumberland Fontworks at

http://www.cumberlandgames.com

