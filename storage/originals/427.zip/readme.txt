This is a font file from www.workorspoon.com
Copyright 2002.  All Rights Reserved.  

This font is freeware.  You may use it however you like and distribute it as long as it is not modified


-----

Which is more painful - Going to work or gouging your eye out with a spoon?
Find out at www.workorspoon.com