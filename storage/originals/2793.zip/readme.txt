TrueTypeFont: DreamScar
Dennis Ludlow 2001 all rights reserved
Sharkshock Productions
maddhatter_dl@yahoo.com

Hey there everyone. This is my first real "orginal" font that hasnt been inspired by a logo or 
anything else like that. It is very limited and should'nt be used for much more than basic
documentation. Nonetheless, i had fun with it and i hope you do too.
check out my graphic archive at www.sharkshock.uni.cc
                                  "because boring design SUCKS!"