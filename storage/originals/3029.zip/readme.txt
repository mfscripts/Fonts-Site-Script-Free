

[utopiafonts] 1998 free font
----------------------------------------------------

this font is provided free for personal use,
it was created by loki using:
macromedia fontographer 4.1
adobe photoshop 3.0
a fineliner
& a whiteout pen

FREE FONTS
----------
if you would like your own free font, just send your handwriting
samples, concepts or scans to me at: dale_thorpe@bssc.edu.au

MAILING LIST
------------
join the utopiafonts mailing list by sending an email to:
subscribe-utopiafonts@egroups.com or just visit our webpage at:
http://utopiafonts.home.ml.org/

----------------------------------------------------
� 1998 utopiafonts.home.ml.org