Thanks for downloading STONE-AGE

DESCRIPTION:

Urg! Gur-No Ko-Lak! Or, should I just give up and yell "Yabba-Dabba-Doo!!??" STONE-AGE has the rough-hewn look of other caveman-style fonts, yet it is somehow completely different. Sets well at point sizes 18 and above, but still manages to read well at smaller sizes. This font only has the following punctuation: period, exclamation mark, question mark, ampersand, asterisk. Upper- and lower-case characters are identical, but it does have a full number set (0-9). Knock yourself out with it anyway.

This font is free to use in all your designs and layouts. STONE-AGE may be duplicated and given away as often as you see fit, as long as you INCLUDE THIS README FILE. Please don't rename it, and/or tell people you made it, or an enraged caveman may club you senseless.

INSTALLING STONE-AGE:

MACINTOSH:
For System 7 and above, just drag both the "Stone-Age.bmap" and the "StoneAge" files onto your system folder icon. Finder will prompt you whether or not to add them to your Fonts folder; click OK and you're set! If you're using font management software like Suitcase, consult your user's manual for further instruction.

WINDOWS:

Windows 3.1: Open the control panel and choose FONTS
Click the ADD button, find the TrueType font, and click OK.

Windows 95 and above: Open the Windows FONT folder; click, drag, and drop the TrueType font inside.

DISCLAIMER (This notice MUST be included with any distribution):

No guarantee of any kind is made this this will work on your machine. I've tested it on mine, and it works fine. Dave Bastian MAKES NO WARRANTIES, EXPRESS OR IMPLIED, REGARDING THIS FONT. Dave Bastian DOES NOT WARRANT, GUARANTEE OR MAKE ANY REPRESENATIONS REGARDING THE USE OR THE RESULTS OF THE USE OF THIS FONT IN TERMS OF ITS RELIABILITY, OR OTHERWISE. IN NO EVENT WILL Dave Bastian BE LIABLE TO YOU FOR ANY DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE Stone-Age. So, before you cast any stones, just consider how much you paid for this...

Please take a moment to mention where you found STONE-AGE and feel free to comment or criticize, care of "fonts@davebastian.com"

I'm not holding my breath, but if you use this font for a commericial project  or design something really fantastic with it, drop me a line.

Other free fonts available at "http://www.davebastian.com"
