------------------------------------------------------------------
DISTANT GALAXY v1.2, created by ShyWedge, 1999.
------------------------------------------------------------------

The following TrueType fonts are included:

- Distant Galaxy 
- Distant Galaxy, Italic
- Distant Galaxy AltOutline
- Distant Galaxy AltOutline, Italic
- Distant Galaxy Condensed
- Distant Galaxy Condensed, Italic
- Distant Galaxy Outline
- Distant Galaxy Outline, Italic

v1.2 UPDATES
------------------------------------------------------------------

- Numbers and punctuation have been added.
- Rebel Alliance insignia has been added (press shift+2).
- Imperial insignia has been added (press shift+8).
- Better lettering, spacing, and kerning.

This font is freeware.  So, enjoy.  If you choose to distribute
this font, please include all of the fonts and this document.  
If you place this font on your Web Site, e-mail me to let me know 
so I can inform you of the latest updates.


Created by ShyWedge, 1999.
E-mail: ShyWedge@yahoo.com


