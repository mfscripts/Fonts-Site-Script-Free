A LOGO FACTORY TYPEFACE
=======================


RULES OF USAGE
--------------

This font was designed by James Helps of The Logo Factory, 
and is free to use for personal use. If you wish to use
this font commercially please contact The Logo Factory at 
logofactoryuk@hotmail.com. 

This font can also be supplied as Type 1 for the PC or
the MAC.


CONTACT
-------

Please feel free to contact the designer of this font, 
James Helps, at logofactoryuk@hotmail.com.

If you you wish to visit The Logo Factory web-site 
please do so at http://www.jameshelps.com/thelogo factory


SERVICES
--------

The Logo Factory has a number of years experience in the 
field of design and offers a whole-host of typographical 
and logo solutions.

Logo Design : 

The Logo Factory can create a logos what ever the size of business
whatever you need to for. Prices start at �55 ($100).

Tailor-made Typefaces :

If you need a type face for a unique identity we can 
supply it, taking into consideration it's usage, your type 
of business and existing identities. 

Handwritting : 

We offer the service of turning your handwritting into your 
own unique typeface.

Typesetting : 

If you are looking for that right look and feel for your design 
work, such as newsletters, brouchers, etc. The Logo Factory can 
offer you a typesetting service second to none.


