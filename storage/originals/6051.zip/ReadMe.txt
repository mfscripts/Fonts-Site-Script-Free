FUTUREX APOCALYPSE
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

There are lots of things to love about Apostrophic Laboratories <http://www.apostrophiclab.com/>, from the world's most comprehensive freeware comicbook font family to a huge collection of modern designs that should be in any graphic designer's toolbox. They give all of it away with a smile and a cheery Flash animation.

One of the fonts they give away is called Futurex, a bundle of 8 fonts intended to be the beginning of an open-ended "everyone's invited" fontbuilding project. When one of the Lab (Fleisch) emailed me recently, I discovered Futurex by following her bio links, and decided I'd join in, and dragged Futurex Bold into Photoshop to work it over with a rusty chain and a tub of acid. The result, Futurex Apocalypse, is now yours.

This font is freeware for any private or commercial use; distribute it all you like, as long as it remains free - It's not for sale! Enjoy!

Version 1.1

