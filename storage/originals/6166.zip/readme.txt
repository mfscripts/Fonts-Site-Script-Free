Hey fontmonglers and biffs..

Ya have de'unleuded a free font from da Fontex 2000mg metropol - the world.
Ho' do ya like it?? ey? ver'y goody goody or bad..
If you wanna use 'it on da homepaigee of your'ss - tell me. I wanna gaze at it.

Do ya know da story, buddy? No? well, righty righty - listen here:
This font was named by Eric Perlin.
True Type Resource has a Name A Font page where you can name a font
from one of the web's best type designers. Check it out.
True Type Resource http://www.typesource.com

My english suck I know, but its funny, ey??

My brain is in the cupboard, above the kitchen sink..
www.mrfisk.com <-------------where my fonts ar' a livin their precious life
www.undergroundstar.nu <----------my music wich I have pasted togethe'r on da
strings of a huge gitzar.

------------------------------------------------------------------------------
Now send me some money so I can eat..
M.Larson
Lagergrensg 13
60350 Norrkoping.
Sweden.