Parseltongue v1.0     --December 17, 2000-- (released Oct 31, 2001)

Hello!  Thanks so much for checking out "Parseltongue," an original font inspired by J.K. Rowling's Harry Potter books.  The serpentine aspects of the font and the font's title have to do with the second book of the series, _The Chamber of Secrets_. 

I hope you enjoy this Art Nouveau-ish Potterly font. A word to the wise: it definitely works best for display text. 

You are welcome to share this free font with your friends. Please distribute 
it with this readme (the compressed file is an easy way to pass it along!)
As always, CarpeSaponem fonts is in no way affiliated with J.K. Rowling or any of her publishers.

Have fun!

><> Sarah McFalls
CarpeSaponem Fonts (also the home of the Lumos font)
hedwig@owlmail.com <---contact me here w/any questions!
http://www.geocities.com/carpesaponem/


