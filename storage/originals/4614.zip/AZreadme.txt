____________________________________________________
                                                    |
First of all: this font is FREE<!       <<<---------|

Originally this font was made for a poster anouncing a music concert.
As some might already have noticed it is based on Griffon. I messed
around with it in different graphic programs. Have fun with it!
You know, I am really interested in what ways you are using my fonts-
so if you like just let me know when and what for you used them.

for more information visit my web-site:www.cuci.nl/~nonsuch/

mailto-------->hannmueller@metronet.de
                 if for some reason that adress doesn't work 
                                                    mailto:|
                                                           |
                                      nonsuch@cuci.nl <____|
COPYRIGHTS:<!--------------------------------------------------------|
                                                                     |
"AutonomesZentrum Crushed" is copyright (c) Christoph Mueller 1997.  |
You are not allowed to sell, redistribute or alter it in any form    |
without written permission. If you are interested in offering it     |
from your web-site mail me.                                          |
                                   <<<-------------------------------|


-----Mueller                        