DS VTCorona Cyr (VTCorona - old)
----------------------------------------------
D-Studio (Moscow) & Susan Townsend
(c)1998, All rights reserved.
Freeware version.

* * * * * * * * * * * * * * * * * * * * * * * *

D-Studio (Moscow)
http://wt.aha.ru/d-studio/
webart@tomcat.ru
Dubina Nikolay
&
FredaPple@aol.com
Susan Townsend

* * * * * * * * * * * * * * * * * * * * * * * *