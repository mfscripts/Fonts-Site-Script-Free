--------------------------------------------------------------------
SF ATARIAN SYSTEM v1.0, created by ShyWedge, 1999.
--------------------------------------------------------------------

The following TrueType fonts are included:

 - SF Atarian System
 - SF Atarian System, Italic
 - SF Atarian System, Bold
 - SF Atarian System, Bold Italic
 - SF Atarian System Extended
 - SF Atarian System Extended, Italic
 - SF Atarian System Extended, Bold
 - SF Atarian System Extended, Bold Italic

v1.0 FEATURES
--------------------------------------------------------------------

 - Includes uppercase and lowercase letters, numbers, and limited 
   punctuation.
 - Proper spacing and kerning.

SPECIAL CHARACTERS
--------------------------------------------------------------------

 - Atari Fuji Logo 1 ----------------------------- press @
 - Atari Fuji Logo 2 ----------------------------- press #
 - Atari Fuji Logo 3 ----------------------------- press *


TERMS OF USE
--------------------------------------------------------------------

By downloading any of our font packages you agree to the following
terms of use:

 - Every FONT PACKAGE available for downloading on SHYFONTS is
   FREEWARE and may be distributed ONLY via the Internet for FREE.
   Under NO circumstances may any FONT PACKAGE be sold for a
   profit nor be included as part of another product or CD-ROM
   compilation.  If you wish to include any of our FONT PACKAGES
   for FREE distribution on your Web Site, please include all of
   the fonts and original documentation supplied with each FONT
   PACKAGE.  For the latest releases and updates, check our Web
   Site at http://welcome.to/ShyFonts.

 - You may install and use our FONT PACKAGES on an unlimited
   amount of machines.

 - You may NOT rename, edit, or create any alternate variations of
   the fonts included in our FONT PACKAGES except when embedding
   them in documents.

 - Every FONT PACKAGE comes "as is" with NO warranty whatsoever.
   SHYFONTS accepts NO responsibility for any damages or loss of
   any kind due to the use of our FONT PACKAGES.  The use of our
   FONT PACKAGES is solely your responsibility -- you use each
   FONT PACKAGE at your own risk.

If you have any question regarding this document or the usage of
our font packages, feel free to contact us at ShyWedge@yahoo.com.



Thank you for downloading this font package and enjoy!

ShyFonts by ShyWedge, 1999.
--------------------------------------------------------------------
Web Site:  http://welcome.to/ShyFonts
E-mail:    ShyWedge@yahoo.com