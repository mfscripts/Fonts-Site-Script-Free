

d i s t u r b e d   d o t   c o m   f r e e f o n t :

	11.16.97	TAXIDERMIST



this typeface is copyright 1997 by matthew austin petty.

redistribution of this font is strictly prohibited by law.  do not redistribute it.

please, enjoy this font, and use it often.  use it cool places like magazines, and gum 
wrappers, and frito lay products, and stuff like that.

for more vitamin-packed abc's, please visit http://www.disturbed.com

i like you a whole lot,
matthew austin petty
webmaster@disturbed.com
http://www.disturbed.com