ALMANAC OF THE APPRENTICE
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

Often as not, the fonts I post are those I�ve built for a specific graphics project, and that�s the case with this one, ALMANAC OF THE APPRENTICE. The name is a simple-minded jest, a reference to the fact that this is a cruder, simpler, and more casual cousin of ATLAS OF THE MAGI. �Almanac� is also built of a heavier line-weight, and to achieve the effects I wanted I doodled the original sample much smaller than I did its more formal relative. This isn�t quite a complete keyboard set; it�s an all-caps display set with select punctuation and a few glyphs duplicated as placeholders (the brackets are identical to the parentheses, for example, but the curly-brackets are at least a variant of them). At any rate, it�s friendly and fun. Enjoy!

This font is copyright � 2005 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for private, non-commercial use. Contact me at sjohn@io.com if you're interested in an inexpensive commercial license.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0
