DF667 Font Foundry

e-mail: us@diagnostik.force9.co.uk

address:
Unit 2, 109 Baron Court
Chandlers Way, Temple Farm Industrial Estate
Southend-On-Sea, Essex, SS2 5SE, England



Our fonts have now been declared 'Treeware'

in order to use this font we would like you to pay the price of one cheesy postcard (along with a stamp!) to the OBLONG address. On the back of the postcard you should draw your favorite shape or symbol along with your e-mail adress & if we like it we will send you our favorite piece of crap, electronically or otherwise.

P.S. all fonts remain the property of OBLONG/DF667. Violations will be laughed at sarcastically so cut us some slack and give us credit were possible (we love the attention).

If you intend on using DF fonts for commercial gains then please contact us...At the very least you could send us an e-mail saying:

"I sold my soul to Santa for DF fonts"

go on...do it!