ATLAS OF THE MAGI
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

This is one of those "necessity is the mother of invention" fonts. I'm doing some fantasy maps for work, and I needed a wide, hand-drawn Roman font with a quirky style to use for the kingdom labels. Couldn't find what I wanted, so I drew it . . . Since I'll probably also be using Apple Butter in the same project, I went for a related line style, and I like the results a lot. I drew the font with a Sharpie on cheap graph paper, to achieve lots of rough ink-bleed to get the edges how I wanted them. I think I also permanently stained the table at a fast-food place downtown. Oops.

This is a letters, numbers, and a (very few) other characters font. There's some basic punctuation, and parentheses, and not much else (if you desperately need a tilde in this style, you have my sincere apologies). Enjoy!

Version 1.11

This font is copyright 2002 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for personal, non-commercial use of any kind (including website decoration and so on). Contact me at sjohn@io.com if you're interested in a commercial license; rates will depend on the details.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.
