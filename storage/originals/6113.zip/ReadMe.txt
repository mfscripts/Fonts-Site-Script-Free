YANK
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

This is a font I've been meaning to make for a while, and the bug finally bit. Really, it bit a long time ago, and the result was Lunatic, my first-ever for-real whole-darn-keyboard set font. I made Lunatic with no idea what I was doing, and it came out pretty nice . . . But also a little wonky (hence the title I gave it). At any rate, Lunatic is still a favorite, and it was good enough to satisfy me then.

Later on, I made Newfie (you can find all these on the Fontworks, by the way), a more serious, lessons-learned-and-applied handwriting font based on my wife's own hand. Sandra's a Newfie, so I called it that.

In Newfoundland, they call Americans "yanks." So now, I have a proper "his" font to match Sandra's "hers" font . . . a serious, lessons-learned-and-applied handwriting font, a slightly more sober cousin to Lunatic.

Sadly, my "sane" handwriting isn't much more legible than my lunatic handwriting, but this font is as close to the Real Deal as I can make it. It's a full keyboard set, with a couple of extras, and lots of hand-guided kerning. Enjoy.

Version 1.4

This font is copyright 2001 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for personal, non-commercial use of any kind (including website decoration and so on). Contact me at sjohn@io.com if you're interested in a commercial license; rates will depend on the details.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.