========================================================
ReadMe file contained in rufbrush.zip sent to redsun.com
========================================================

All fonts are MS Windows 3.1 TrueType generated from Fontographer 4.1 for/Win.

Willow - My most recently completed project. A very "clean" looking font. Recreated the letterforms from a commercial font by scanning a printed copy and re-drawing the outline from the scanned bitmap. Like GrekoDeco, this font is reminiscent of the Art Deco heyday of the 20's.


Also available at redsun.com:

GrekoDeco - My next and most involved type project. A round, friendly, fat display font. I learned Fontographer for Windows doing this one. Fell in love with AutoTrace function. Again, all US English alphanumeric characters and limited punctuation. Original image scanned from a Dover Clipart Book. Created a second font (now called GrekoDeco Bold) without the decorative "knock-outs" so that I could make solid drop-shadows or "masks", thus the background DOESN'T show through the letterforms except through the standard Roman bowls when used in back of or underneath GrekoDeco

DungeonBlocks - Creating this font was very labor intensive, as each letter has a different block structure. Also scanned from a clipart book. Works GREAT when extruded from a drawing program (such as Adobe Illustrator or CorelDRAW) or when given a drop shadow and graduated fill from a painting program (such as Adobe PhotoShop or Fractal Design Painter) to simulate a 3D effect. The two enclosed gif's show a color extrusion from CorelDRAW (dungeon.gif) and a grayscale fill with a dropshadow done in PhotoShop (dungeon2.gif)

DeRoosCaps - Moving along in my mastery of "drawing" programs and my Type construction education. Also done in 1992. Original image scanned from a Dover Clipart Type book. Upper Case & Lower Case are "scaled" versions of each other. Contains US English punctuation and all US Eng alphanumeric characters along with a few "alternate" letterforms placed in ASCII 0161-0166.

RoughBrush - a somewhat "coarse" brushstroke font. Done in 1992 - my first complete font. Originally done in CorelDRAW 3 and later cleaned up in Fontographer. Original image was scanned from a photocopied Press-On-Letter sheet. Contains all US English alphanumeric characters plus punctuation.

GrekoDeco Bold - referred to above


Coming next (perhaps within a week or two) :  Zoom 1, a modern, angular typeface suggesting horizontal movement by using 15 horizontal stripes graduating down in heigth across 10 vertical zones on each letter.

Although I give permission to post these fonts for distribution at redsun.com and have absolutely no objection to their non-commercial use, I still retain my commercial rights to them and prohibit their outright sale.
