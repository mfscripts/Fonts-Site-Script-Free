                   Readme file for JSL Blackletter font
                             26 August 1997

The "JSL Blackletter" font is based upon a typeface created  by  William
Bullokar, for his "Booke at large, for the amendment of orthographie for
English speech", published in 1580 by  Henrie  Denham.   In  this  book,
Bullokar  attempted to regularise the spelling of English by adding some
letters to the English alphabet (mostly  combinations  of  two  letters,
such as "sh" or "ph"), and by using accents to mark the pronunciation of
vowels.

He also provided several example typefaces,  including  the  blackletter
alphabet  which  is  the basis for this font.  His new letters have been
removed, as I originally designed this font for the  purpose  of  repro-
ducing some blackletter broadside ballads which used the normal  English
orthography  of  the period.  (Obviously, his idea was met with the same
enthusiasm that was shown to the Metric System by the United States...)

I used Fontographer 3.5.2 to produce this font.  Because  it  uses  ANSI
encoding,  the  glyph  mapping will be somewhat different under OS/2 and
the Macintosh. Unfortunately, most of the cool ligatures  are  not  used
by the default OS/2 codepage (which all of the applications seem to use,
regardless  of  the  config.sys  setting),  so   they're   pretty   much
inaccessible.

The ISO Latin-1 characters (32-127, 160-255) are all  present;  many  of
the  extended Windows characters (128-159) are present as well, but some
have been replaced in order to provide  certain  ligatures  and  archaic
characters:

Character                     
  Code      JSL Blackletter   Arial
-----------------------------------------------------------------
   0131     Long 's'          florin (script f)
   0134     'st' ligature     dagger
   0135     unused            double dagger
   0142     'ff' ligature     unused
   0143     dotless 'i'       unused
   0144     half 'r'          unused
   0157     'ss' ligature     unused

Under OS/2, the only special character available is the long 's',  which
can be accessed as Alt-159.

Certain Windows 3.1 printer drivers do not output characters  which  are
"unused"  by  the  base  Windows  character  sets (such as the half 'r')
unless the "Output TrueType fonts as graphics" box  is  checked  in  the
printer driver.  This problem may or may not occur under Windows 95, but
I can't say for certain.

JSL Blackletter is copyright (c) 1997 by Jeffrey S. Lee.  Permission  is
granted  to  freely  distribute  it,  provided  that  it  is distributed
unaltered, and it is accompanied by this  text  file.   It  may  not  be
included  in  any  commercial  package without prior permission from the
author.  This font is "emailware"; if you like it and decide to use  it,
please send me email at the address listed below.  I will not charge you
any money or send you annoying email  spam;  I'm  simply  interested  in
who's  using it, and I'd be happy to receive any comments you might have
about the font.

                                           Jeff Lee
                                           http://www.gate.net/~shipbrk/
                                           shipbrk@gate.net
