
bearpaw & bearpaw bats
----------------------------------------------------

these fonts were provided free for personal or commercial use,
they can be redistributed however they may not be sold.  

these fonts are distributed by utopiafonts with permission
from the artist, Dennis Anderson.

----------------------------------------------------
� 1999 dennis anderson. fonted in utopia