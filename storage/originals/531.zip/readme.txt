Catharsis Espresso
******************

A TrueType font created by Christian Thalmann (cinga at gmx dot
net, www.cinga.ch).  Distribute and use freely, but not without this 
readme file.  If you should use it for a poster campaign, flyer, 
invitation or something, I'd appreciate it if you'd send me an e-mail 
about it.  I like to see my work put to use.  =)

This font is aimed at coffee bars and the likes, hence the name.  It 
offers a range of ligatures; use a keyboard tool to find them all.
Unlike its sister font Catharsis Macchiato, it contains no lowercase
characters, but instead offers most characters in narrow and extrawide
versions, as well as a few alternative shapes.

I'm rather proprietary about the Itchy Dog logo; do not use it for 
any commercial purpose, and accompany any public purpose with an 
explicit reference to me.



-- Christian Thalmann






