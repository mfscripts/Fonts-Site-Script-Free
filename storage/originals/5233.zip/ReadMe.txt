6/7/97     mintcure@geocities.com     http://www.geocities.com/SunsetStrip/Palms/1552
Hi...this is a font that I made modeled after the Cure's Caterpillar 12" single.
To install it: 
Mac: drop into your system folder.
Windows 95: put into c:\windows\fonts.
Windoze 3.x: Open up the Control Panel. Double click on Fonts. Click Add (or is it install?) new font. Point it over to where the new font is. Click OK or Intall or Add or whatever. (Please note: it's been a long time since I've used Win 3.11, so I am doing this just by memory!)

If you need more help, please feel free to e-mail me!

Please feel free to distribute this font as long as it is unchanged and you keep this readme file with it.
**If you use it or feature it on a web page, PLEASE E-MAIL ME! I just like to keep track of it's whereabouts!**

This font is SHAREWARE! That means that if you use it and you like it you should pay for it. Please! I spent countless hours and who knows how much irreversible wrist damage working on this font...Support shareware and pay! Please don't use this font on web pages, art, or anything else without registering it!

If you don't want to pay me but would other wise like to show your *undying gratitude*, e-mail me and we can work out a deal...perhaps some nifty Cure bootlegs or what have you... =)

I am only asking $5....I think that's more than reasonable, don't you?

Please send to:

Jennifer Dickert
20 Spring St.
Apt. B-2
Norwalk, CT
06854
USA

mintcure@geocities.com
http://www.geocities.com/SunsetStrip/Palms/1552

This font could not have been possible if not fot the sheer elegance, stability and ease of use of the Macintosh OS....

Hey Windoze users: does this sound familiar?

Bad Windoze!!!
Roll over! 
Uhhhh....play dead? 
Goooooood Windoze! 
How would you like mommy to give you a nice cold reboot? 
Then will you behave for mommy?

I think you get the idea...

The Cure, The Caterpillar and it's artwork are all copyright the Cure, Parched Art, Fiction Records, Electra Records and anyone else affiliated with the Cure and this single. Please don't sue me! I am just a lowly college student who does this as a lobor of love!