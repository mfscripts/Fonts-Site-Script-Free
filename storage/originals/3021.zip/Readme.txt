This font is Freeware
=================================================================
Designer: Gabrielle Gaither 
(c)1998, 1999, 2000 Gabrielle Gaither
http://www.justkissme.com
=================================================================

The attached font below MAY NOT be altered or regenerated in any way for the 
purpose of creating other fonts.  This font cannot be redistributed on CD or on any 
media form for the purposes of profit.  Font making is a tedious and exacting art.  
Please respect the time and energy I have expended in creating this font.

For a complete listing of my fonts at this site use the following address:
http://www.makambo.com/fonts/designer.jsp?affiliateid=114411?sid=950309601015-3438290537-173&authorid=336

If you wish to distribute this font, please contact me at gab@justkissme.com for permission.