  *        *
hello there font lover you've downloaded a
*		*
SOLAR*SISTER font 

from www.hellostranger.com/solarsister/

  *	        * *
   *      *		   *      *
	*	*
there are only a few rules:
		*			*
The fonts are all free ware, which means you can do pretty much
whatever the hell you want with them, except claim them as your own,
of course. If you use them though, I'd like to see where. Drop me a line:

solarsister@hellostranger.com. 
                   *					*
However, if you want to redistribute any of the typefaces contained
herein, please ask first. Of course, this read-me file must be attatched. 

     *	        * *
   *      *		   *      *
	*

send me a postcard with your e-mail address and I'll send you a special font
 *      *		   *      *
PO Box 616
Mt Lawley WA 6929
Australia
 *      *		   *      *
  *	        * *
   *      *		   *      *
	*