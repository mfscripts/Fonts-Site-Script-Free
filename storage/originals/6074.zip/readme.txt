
	Mcgannahan A Dogstar Font


Please Read Me...


The Mcgannahan Font is Shareware and copyright �1998 Dogstar (All Rights Reserved)  If you have any doubt about anything, please get in touch.

Mcgannahan is a fully featured TrueType font, with over 200 characters (upper and lower case, numerals, foreign characters, punctuation and symbols), based on the hand lettering/printing style of the cartoonist, comix creator and illustrator Graham Higgins. It is available for both the Windows and Macintosh platforms.

# Please Note � The generic currency symbol ASCII 219 (Mac � shift�option 2 and Windows � ALT+0164) has been replaced by the EURO (the new pan european single currency) symbol.


* Registering

You may use this font free of charge for evaluation purposes only. If you want to use this font for commercial or noncommercial publishing purposes (this includes all forms of electronic as well as hard copy publishing), you are obliged to register and pay your shareware fee.

Please register the Mcgannahan font, it costs just US$10 for a single user license. Site licenses ($200) and world�wide licenses ($1000) are also available. A site license covers all machines in the organization which are within 100 miles of a central point, world�wide means this planet only�

Paying for Mcgannahan is fairly simple. Open the Register program that accompanies Mcgannahan. Enter your name, your email address, and the number of single user licenses you desire (or Site or Word�Wide licenses). Save or Copy or Print the data from the Register program and send the data and payment to Kagi. Kagi handles my payment processing.

If paying with Credit Card or First Virtual, you can email or fax the data to Kagi. Their email address is sales@kagi.com  and their fax number is +1 510 652�6589. You can either Copy the data from Register and paste into the body of an email message or you can Save the data to a file and you can attach that file to an email message. There is no need to compress the data file, it's already pretty small. If you have a fax modem, just Print the data to the Kagi fax number. 

Payments sent via email are processed within 3 to 4 days. You will receive an email acknowledgement when it is processed. Payments sent via fax take up to 10 days and if you provide a correct internet email address you will receive an email acknowledgement. 

If you are paying with Cash or USD Check you should print the data using the Register application and send it to the address shown on the form, which is: 

�Kagi
�1442�A Walnut Street #392�Q8X
�Berkeley, California 94709�1405
�USA

Or register online <http://order.kagi.com/?Q8X>



* Distribution

You may copy and hand on the complete font archive, but not the single or individual files. This is to ensure that only complete and undamaged packages containing the font, the read me document and the registration application are being distributed.

The Mcgannahan font distribution package may be distributed in any way as long as you do not charge for it, beyond reasonable download charges on systems that charge for connect time.


* Disclaimer

Dogstar ("the author") hereby disclaims all warranties relating to this software, whether express or implied, including without limitation any implied warranties of merchantability or fitness for a particular purpose. The author will not be liable for any special, incidental, consequential, indirect or similar damages due to loss of data or any other reason, even if the author or an agent of his has been advised of the possibility of such damages. In no event shall the author be liable for any damages, regardless of the form of the claim. The person using the software bears all risk as to the quality and performance of the software.

* Updates and Other Dogstar Fonts

	This version release last modified: Tue, Nov 16, 1999

Updates and the latest revisions to this font and other Dogstar fonts are available at:
				
				http://www.mamba.demon.co.uk/dogstar


* Acknowledgements

Thanks to Graham Higgins � http://www.pokkettz.demon.co.uk � for his support, help and generosity in the creation of this font


* Contacting Dogstar

Dogstar
dogstar@kagi.com
http://www.mamba.demon.co.uk/dogstar
fax: +44 (0)121 624 9109

