Honest John's and Honest John's Shadow computer fonts �2000 Harold Lohner

FREEWARE-Distribute freely.

Based on the classic Howard Johnson's restaurants logo.

HLohner@aol.com
http://members.aol.com/fontner