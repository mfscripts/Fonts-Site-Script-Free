This is the TOWERING font. Fear it, worship it, obey it. 
Also, let me know what you think of it. I would appreciate any feedback.
Thanks.
Robert Thompson
original_name@mailexcite.com

This font is free for your own use, but if you want to use it commercially, please e-mail me to get permission. Thanks.