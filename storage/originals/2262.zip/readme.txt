Flight of the Dragon Font

This font was created by Rob Anderson of Flight of the Dragon,
using CorelDRAW version 5 and 6. This font is freely available,
may be distributed in any way as long as this message is included.

The author makes no guarantee about the viablity and usability of
this font and is not responsible for any damages related to the
the use.

All rights reserved
Copyright 1997, Flight of the Dragon